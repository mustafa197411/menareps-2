import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./firebase", () => ({ auth: { currentUser: { getIdToken: vi.fn(async () => "TOKEN") } } }));
import { createAdminOfferDraft, getAdminOfferCommercialOptions, listAdminOffers, mutateAdminOffer, OfferAdminClientError } from "./offerAdminClient";

describe("Offer administration authenticated client", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("loads Offers with a Firebase bearer token", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ offers: [], capabilities: {} }), { status: 200 }));
    expect((await listAdminOffers()).offers).toEqual([]);
    expect(fetchMock).toHaveBeenCalledWith("/api/offers", expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer TOKEN" }) }));
  });

  it("loads sanitized commercial options from the authenticated endpoint", async () => {
    const body = { state: "ONE", relationships: [{ companyMarketId: "SYNTHETIC_RELATIONSHIP", companyId: "SYNTHETIC_COMPANY", marketId: "SYNTHETIC_MARKET", countryId: "SYNTHETIC_COUNTRY", companyName: "Synthetic Company", marketName: "Synthetic Market", countryName: "Synthetic Country", currencyCode: "XAA", products: [{ productId: "SYNTHETIC_PRODUCT", name: "Synthetic Product" }] }] };
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify(body), { status: 200 }));
    expect(await getAdminOfferCommercialOptions()).toEqual(body);
    expect(fetchMock).toHaveBeenCalledWith("/api/offers/commercial-options", expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer TOKEN" }) }));
  });

  it("returns controlled permission and stale-revision errors", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValueOnce(new Response(JSON.stringify({ code: "OFFER_PERMISSION_DENIED" }), { status: 403 }));
    await expect(listAdminOffers()).rejects.toMatchObject({ code: "OFFER_PERMISSION_DENIED", status: 403 });
    vi.spyOn(globalThis, "fetch").mockResolvedValueOnce(new Response(JSON.stringify({ code: "OFFER_STALE_REVISION" }), { status: 409 }));
    await expect(mutateAdminOffer({})).rejects.toMatchObject({ code: "OFFER_STALE_REVISION", status: 409 });
  });

  it("classifies recoverable read and write network failures", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("offline"));
    await expect(listAdminOffers()).rejects.toEqual(new OfferAdminClientError("OFFER_READ_FAILED", 0));
    await expect(createAdminOfferDraft({})).rejects.toEqual(new OfferAdminClientError("OFFER_WRITE_FAILED", 0));
  });
});
