import { auth } from "./firebase";
import type { OfferCapability, CanonicalOfferDefinition, LegacyOfferPresentation } from "../features/offers/types";

export type OfferAdminReadRecord =
  | { kind: "CANONICAL"; offer: CanonicalOfferDefinition }
  | { kind: "LEGACY"; offer: LegacyOfferPresentation };

export type OfferAdminClientErrorCode =
  | "OFFER_AUTHENTICATION_REQUIRED" | "OFFER_PERMISSION_DENIED" | "OFFER_STALE_REVISION"
  | "OFFER_READ_FAILED" | "OFFER_WRITE_FAILED" | string;

export class OfferAdminClientError extends Error {
  constructor(public readonly code: OfferAdminClientErrorCode, public readonly status = 0) {
    super(code);
    this.name = "OfferAdminClientError";
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token = await auth.currentUser?.getIdToken();
  if (!token) throw new OfferAdminClientError("OFFER_AUTHENTICATION_REQUIRED", 401);
  let response: Response;
  try {
    response = await fetch(path, {
      ...init,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(init?.headers || {}) },
    });
  } catch {
    throw new OfferAdminClientError(init?.method === "POST" ? "OFFER_WRITE_FAILED" : "OFFER_READ_FAILED", 0);
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new OfferAdminClientError(typeof body.code === "string" ? body.code : "OFFER_WRITE_FAILED", response.status);
  return body as T;
}

export interface OfferAdminListResponse {
  offers: OfferAdminReadRecord[];
  capabilities: Record<OfferCapability, boolean>;
  authorizedScope: { companyIds: string[]; countryIds: string[]; marketIds: string[] };
}

export interface OfferCommercialOptionsResponse {
  state: "ZERO" | "ONE" | "MULTIPLE";
  relationships: Array<{
    companyMarketId: string; companyId: string; marketId: string; countryId: string;
    companyName: string; marketName: string; countryName: string; currencyCode: string;
    products: Array<{ productId: string; name: string }>;
  }>;
}

export const listAdminOffers = () => request<OfferAdminListResponse>("/api/offers");
export const getAdminOfferCommercialOptions = () => request<OfferCommercialOptionsResponse>("/api/offers/commercial-options");
export const createAdminOfferDraft = (definition: unknown) => request<{ offer: CanonicalOfferDefinition }>("/api/offers/drafts", { method: "POST", body: JSON.stringify({ definition }) });
export const mutateAdminOffer = (command: unknown) => request<{ offer: CanonicalOfferDefinition }>("/api/offers/actions", { method: "POST", body: JSON.stringify(command) });
