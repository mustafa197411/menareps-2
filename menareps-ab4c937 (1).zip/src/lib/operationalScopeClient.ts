import type { User as FirebaseUser } from "firebase/auth";

export type OperationalBoundaryKind = "AREA" | "COUNTRY" | "REGION" | "GLOBAL";
export type OperationalSubjectMode = "SELF" | "HIERARCHY";

export interface CanonicalOperationalScope {
  authorized: boolean;
  code?: string;
  actorUid?: string;
  role?: string;
  boundaryKind?: OperationalBoundaryKind;
  subjectMode?: OperationalSubjectMode;
  subjectUids: string[];
  authorizedRepresentativeUids: string[];
  countryIds: string[];
  regionIds: string[];
  districtIds: string[];
  cityIds: string[];
  areaIds: string[];
  productIds: string[];
  productGroupIds: string[];
  queryPlan: {
    denyAll: boolean;
    areaIdChunks: string[][];
    subjectUidChunks: string[][];
    productIdChunks: string[][];
    requiresPostFilter: boolean;
  };
  diagnostics: {
    excludedAssignmentIds: string[];
    malformedAssignmentIds: string[];
    outsideBoundaryAssignmentIds: string[];
  };
}

export interface OperationalScopeTokenProvider {
  getIdToken(forceRefresh?: boolean): Promise<string>;
}

const stringArray = (value: unknown): value is string[] =>
  Array.isArray(value) && value.every((item) => typeof item === "string");

const stringChunks = (value: unknown): value is string[][] =>
  Array.isArray(value) && value.every(stringArray);

export const isCanonicalOperationalScope = (value: unknown): value is CanonicalOperationalScope => {
  if (!value || typeof value !== "object") return false;
  const scope = value as Record<string, any>;
  const plan = scope.queryPlan;
  const diagnostics = scope.diagnostics;

  return typeof scope.authorized === "boolean"
    && stringArray(scope.subjectUids)
    && stringArray(scope.authorizedRepresentativeUids)
    && stringArray(scope.countryIds)
    && stringArray(scope.regionIds)
    && stringArray(scope.districtIds)
    && stringArray(scope.cityIds)
    && stringArray(scope.areaIds)
    && stringArray(scope.productIds)
    && stringArray(scope.productGroupIds)
    && plan && typeof plan === "object"
    && typeof plan.denyAll === "boolean"
    && stringChunks(plan.areaIdChunks)
    && stringChunks(plan.subjectUidChunks)
    && stringChunks(plan.productIdChunks)
    && typeof plan.requiresPostFilter === "boolean"
    && diagnostics && typeof diagnostics === "object"
    && stringArray(diagnostics.excludedAssignmentIds)
    && stringArray(diagnostics.malformedAssignmentIds)
    && stringArray(diagnostics.outsideBoundaryAssignmentIds);
};

export async function fetchCanonicalOperationalScope(
  user: Pick<FirebaseUser, "getIdToken"> | OperationalScopeTokenProvider,
  fetchImplementation: typeof fetch = fetch,
): Promise<CanonicalOperationalScope> {
  const token = await user.getIdToken();
  const response = await fetchImplementation("/api/operational-scope", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: "{}",
  });

  const payload: unknown = await response.json();
  if (!isCanonicalOperationalScope(payload)) {
    throw new Error("Malformed operational-scope response");
  }
  return payload;
}
