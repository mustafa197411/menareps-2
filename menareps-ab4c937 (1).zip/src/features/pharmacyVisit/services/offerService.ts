import { auth } from "../../../lib/firebase";
import { validateCanonicalOfferDefinition } from "../../offers/offerValidation";
import type { CanonicalOfferDefinition } from "../../offers/types";

export class PharmacyOfferReadError extends Error { constructor(public readonly code: string) { super(code); this.name = "PharmacyOfferReadError"; } }
export async function fetchLivePharmacyOffers(request: { pharmacyId: string; productIds: string[]; paidLines: Array<{ lineId: string; productId: string; quantity: number }>; selectedOfferIds: string[] }): Promise<{ offers: CanonicalOfferDefinition[]; unavailableOfferIds: string[]; selectedCombinationAvailable: boolean }> {
  const user = auth.currentUser;
  if (!user) throw new PharmacyOfferReadError("OFFER_AUTHENTICATION_REQUIRED");
  try {
    const token = await user.getIdToken();
    const response = await fetch("/api/pharmacy-offers/scoped-query", { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify(request) });
    const payload = await response.json() as { authorized?: boolean; code?: string; offers?: unknown[] };
    if (!response.ok || !payload.authorized || !Array.isArray(payload.offers)) throw new PharmacyOfferReadError(payload.code || (response.status === 403 ? "OFFER_PERMISSION_DENIED" : "OFFER_READ_FAILED"));
    return { offers: payload.offers.flatMap(value => { const parsed = validateCanonicalOfferDefinition(value); return parsed.valid && parsed.value.lifecycleStatus === "ACTIVE" ? [parsed.value] : []; }), unavailableOfferIds: Array.isArray((payload as any).unavailableOfferIds) ? (payload as any).unavailableOfferIds.filter((id: unknown): id is string => typeof id === "string") : [], selectedCombinationAvailable: (payload as any).selectedCombinationAvailable !== false };
  } catch (error) {
    if (error instanceof PharmacyOfferReadError) throw error;
    throw new PharmacyOfferReadError("OFFER_NETWORK_ERROR");
  }
}
