import { getFirebaseAdminServices } from "./firebaseAdmin";

export interface DeliveredInvoiceRecord extends Record<string, any> { id: string }

export interface DeliveredInvoiceTransactionContext {
  actor: DeliveredInvoiceRecord | null;
  order: DeliveredInvoiceRecord | null;
  existingLedger: DeliveredInvoiceRecord | null;
  profile: DeliveredInvoiceRecord | null;
  pharmacy: DeliveredInvoiceRecord | null;
  market: DeliveredInvoiceRecord | null;
  ledgerId: string;
  create(ledger: Record<string, any>, profile: Record<string, any>): void;
}

export interface DeliveredInvoicePostingRepository {
  runTransaction<T>(
    actorUid: string,
    orderId: string,
    operation: (context: DeliveredInvoiceTransactionContext) => T | Promise<T>,
  ): Promise<T>;
}

function value(snapshot: any): DeliveredInvoiceRecord | null {
  return snapshot.exists ? { ...snapshot.data(), id: snapshot.id } : null;
}

export function createFirestoreDeliveredInvoicePostingRepository(): DeliveredInvoicePostingRepository {
  const { db } = getFirebaseAdminServices();
  return {
    async runTransaction(actorUid, orderId, operation) {
      return db.runTransaction(async (transaction: any) => {
        const actorRef = db.collection("users").doc(actorUid);
        const orderRef = db.collection("orders").doc(orderId);
        const [actorSnapshot, orderSnapshot] = await Promise.all([
          transaction.get(actorRef), transaction.get(orderRef),
        ]);
        const order = value(orderSnapshot);
        const invoiceId = String(order?.invoiceNumber || order?.commercialInvoiceNumber || order?.invoiceId || `INV-${order?.displayNumber || orderId}`);
        const safePart = (input: string) => input.replace(/[^a-zA-Z0-9_-]/g, "_");
        const ledgerId = `LEDGER_INVOICE_${safePart(orderId)}_${safePart(invoiceId)}`;
        const ledgerRef = db.collection("customerLedgerEntries").doc(ledgerId);
        const ledgerSnapshot = await transaction.get(ledgerRef);
        const pharmacyId = String(order?.pharmacyId || order?.pharmacy || "").trim();
        const profileRef = db.collection("customerFinancialProfiles").doc(pharmacyId || "__invalid__");
        const pharmacyRef = db.collection("pharmacies").doc(pharmacyId || "__invalid__");
        const marketId = String(order?.marketId || "").trim();
        const marketRef = db.collection("marketSettings").doc(marketId || "__invalid__");
        const [profileSnapshot, pharmacySnapshot, marketSnapshot] = await Promise.all([
          pharmacyId ? transaction.get(profileRef) : Promise.resolve({ exists: false }),
          pharmacyId ? transaction.get(pharmacyRef) : Promise.resolve({ exists: false }),
          marketId ? transaction.get(marketRef) : Promise.resolve({ exists: false }),
        ]);
        return operation({
          actor: value(actorSnapshot), order, existingLedger: value(ledgerSnapshot), ledgerId,
          profile: value(profileSnapshot), pharmacy: value(pharmacySnapshot), market: value(marketSnapshot),
          create(ledger, profile) {
            transaction.create(ledgerRef, ledger);
            transaction.set(profileRef, profile, { merge: true });
          },
        });
      });
    },
  };
}
