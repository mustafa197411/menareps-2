import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const server = readFileSync(new URL("../server.ts", import.meta.url), "utf8");
const page = readFileSync(new URL("../src/components/sales/SalesOffers.tsx", import.meta.url), "utf8");
const rules = readFileSync(new URL("../firestore.rules", import.meta.url), "utf8");

describe("Offer administration API contract", () => {
  it("protects list, detail, create and lifecycle commands with the established Firebase middleware", () => {
    expect(server).toContain('app.get("/api/offers", requireFirebaseAuth');
    expect(server).toContain('app.get("/api/offers/:offerId", requireFirebaseAuth');
    expect(server).toContain('app.post("/api/offers/drafts", requireFirebaseAuth');
    expect(server).toContain('app.post("/api/offers/actions", requireFirebaseAuth');
  });

  it("reserves stale GET /drafts before the dynamic Offer detail route", () => {
    const stale = 'app.get("/api/offers/drafts", requireFirebaseAuth';
    const detail = 'app.get("/api/offers/:offerId", requireFirebaseAuth';
    expect(server).toContain(stale);
    expect(server.indexOf(stale)).toBeLessThan(server.indexOf(detail));
    expect(server).toContain('code: "OFFER_LIST_ENDPOINT_REQUIRED"');
  });

  it("protects sanitized commercial options before the dynamic detail route", () => {
    const options = 'app.get("/api/offers/commercial-options", requireFirebaseAuth';
    const detail = 'app.get("/api/offers/:offerId", requireFirebaseAuth';
    expect(server).toContain(options);
    expect(server.indexOf(options)).toBeLessThan(server.indexOf(detail));
    expect(server).toContain("readOfferCommercialOptions(actor, offerCommercialDependencies)");
  });

  it("sanitizes expected and unexpected errors", () => {
    expect(server).toContain('json({ code: error.code })');
    expect(server).toContain('json({ code: "OFFER_READ_FAILED" })');
    expect(server).toContain('json({ code: "OFFER_WRITE_FAILED" })');
  });

  it("uses backend-only Firestore access and no browser persistence", () => {
    expect(rules).toMatch(/match \/offers\/\{offerId\}[\s\S]*?allow read, create, update, delete: if false/);
    expect(page).not.toContain("localStorage");
    expect(page).toContain("listAdminOffers");
    expect(page).toContain("OFFER_STALE_REVISION_REFRESH");
  });

  it("constructs and injects canonical commercial registry dependencies", () => {
    expect(server).toContain("createFirestoreCommercialMarketRegistryRepository(firebaseAdmin.db)");
    expect(server).toContain("offerCommercialDependencies");
    expect(server).toContain("createOfferDraft(actor, definition, offerRepository, offerCommercialDependencies)");
    expect(server).toContain("mutateOffer(actor, command, offerRepository, offerCommercialDependencies)");
  });

  it("renders loading, empty, denied, retry, capability and lifecycle states", () => {
    expect(page).toContain("Loading Offers…");
    expect(page).toContain("No offers found");
    expect(page).toContain("You do not have permission to administer Offers.");
    expect(page).toContain("Retry");
    for (const capability of ["offers.create", "offers.editDraft", "offers.submit", "offers.approve", "offers.activate", "offers.pause", "offers.cancel"]) expect(page).toContain(capability);
    for (const action of ["SUBMIT", "RETURN_TO_DRAFT", "APPROVE", "ACTIVATE", "PAUSE", "REACTIVATE", "CANCEL"]) expect(page).toContain(action);
  });

  it("does not expose deletion or Pharmacy Visit application operations", () => {
    expect(server).not.toContain('app.delete("/api/offers');
    expect(page).not.toContain("applyDuringVisit\"] &&");
  });
});
