import { describe, expect, it } from "vitest";
import { parseOfferDraftRequest, parseOfferMutationRequest } from "./offerAdministrationRequestContract";

const selection = (companyId = "COMPANY_ALPHA", marketId = "MARKET_ALPHA", countryId = "COUNTRY_ALPHA") => ({ companyId, marketId, countryId, startAt: "2026-01-01T00:00:00.000Z", endAt: "2026-12-31T23:59:59.999Z", productVerificationPolicy: "REQUIRE_ACTIVE_COMMERCIAL_PRODUCTS_AT_OPERATIONAL_USE", marketTimePolicy: "EVALUATE_IN_AUTHORITATIVE_MARKET_TIMEZONE" });
const definition = () => ({ code: "OFFER_ALPHA", name: "Synthetic Offer", type: "PRODUCT_PERCENTAGE", productScope: { mode: "SELECTED_PRODUCTS", productIds: ["PRODUCT_ALPHA"] }, benefit: { kind: "PRODUCT_PERCENTAGE", percentage: 10, base: "ELIGIBLE_PAID_PRODUCT_LINES" }, eligibility: selection(), stackingPolicy: { mode: "NO_STACKING", priority: 0, maximumProductOrQuantityOffersPerPaidLine: 1, maximumInvoicePercentageOffersPerInvoice: 1 } });

describe("strict Offer administration request contracts", () => {
  it("accepts an explicit company-market pair or canonical relationship ID", () => {
    for (const [companyId, marketId, countryId, productId] of [["COMPANY_ALPHA", "MARKET_ALPHA", "COUNTRY_ALPHA", "PRODUCT_ALPHA"], ["COMPANY_BETA", "MARKET_BETA", "COUNTRY_BETA", "PRODUCT_BETA"]]) {
      expect(parseOfferDraftRequest({ definition: { ...definition(), productScope: { mode: "SELECTED_PRODUCTS", productIds: [productId] }, eligibility: selection(companyId, marketId, countryId) } })).not.toBeNull();
    }
    expect(parseOfferDraftRequest({ definition: { ...definition(), eligibility: { ...selection(), companyId: undefined, marketId: undefined, companyMarketId: "COMPANY_MARKET_ALPHA" } } })).not.toBeNull();
    expect(parseOfferDraftRequest({ definition: { ...definition(), eligibility: { ...selection(), companyMarketId: "CONFLICTING_RELATIONSHIP" } } })).toBeNull();
  });

  it.each(["companyName", "countryName", "marketName", "productName", "currencyCode", "currencySymbol", "unitPrice", "derivedPrice", "commercialMetadata"])("rejects client-derived %s", field => {
    expect(parseOfferDraftRequest({ definition: { ...definition(), eligibility: { ...selection(), [field]: "forged" } } })).toBeNull();
  });

  it("requires an explicit market identifier and never substitutes country identity", () => {
    const eligibility = { ...selection() } as Record<string, unknown>;
    delete eligibility.marketId;
    expect(parseOfferDraftRequest({ definition: { ...definition(), eligibility } })).toBeNull();
  });

  it("rejects server-controlled fields and unknown nested metadata", () => {
    expect(parseOfferDraftRequest({ definition: { ...definition(), createdBy: "USER_ALPHA" } })).toBeNull();
    expect(parseOfferDraftRequest({ definition: { ...definition(), productScope: { ...definition().productScope, productNames: ["Forged"] } } })).toBeNull();
  });

  it("parses only bounded lifecycle command shapes", () => {
    expect(parseOfferMutationRequest({ action: "SUBMIT", offerId: "OFFER_ALPHA", expectedRevision: 1 })).not.toBeNull();
    expect(parseOfferMutationRequest({ action: "SUBMIT", offerId: "OFFER_ALPHA", expectedRevision: 1, actorUid: "FORGED" })).toBeNull();
    expect(parseOfferMutationRequest({ action: "DELETE", offerId: "OFFER_ALPHA", expectedRevision: 1 })).toBeNull();
  });
});
