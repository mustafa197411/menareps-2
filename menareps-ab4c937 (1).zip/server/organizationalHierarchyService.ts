import {
  resolveRoleScopePolicy,
  type CanonicalRoleScopePolicy,
  type RoleScopePolicyOverride,
} from "../src/lib/roleScopePolicy";

export type OrganizationalDepth = "self" | "direct" | "descendants";
export type OrganizationalDepartmentScope = "actor" | "all";
export type OrganizationalGeographyScope = "actor" | "all";

export interface OrganizationalUser {
  id: string;
  role: string;
  managerId?: string;
  active?: boolean;
  status?: string;
  employmentStatus?: string;
  accountStatus?: string;
  loginAllowed?: boolean;
  isDeleted?: boolean;
  department?: string;
  country?: string;
  assignedCountries?: string[];
  region?: string;
  district?: string;
  city?: string;
  areaIds?: string[];
  [key: string]: unknown;
}

export interface OrganizationalScopeRequest {
  actorUid?: string;
  depth?: OrganizationalDepth;
  includeSelf?: boolean;
  includeInactive?: boolean;
  departmentScope?: OrganizationalDepartmentScope;
  geographyScope?: OrganizationalGeographyScope;
}

export interface OrganizationalScopeResult {
  actor: OrganizationalUser;
  directReports: OrganizationalUser[];
  descendants: OrganizationalUser[];
  allHierarchyUsers: OrganizationalUser[];
  directReportUids: string[];
  descendantUids: string[];
  allHierarchyUids: string[];
  scopePolicy: CanonicalRoleScopePolicy;
}

export interface OrganizationalHierarchyRepository {
  getUser(uid: string): Promise<OrganizationalUser | null>;
  getDirectReports(managerUid: string): Promise<OrganizationalUser[]>;
  getAllUsers(): Promise<OrganizationalUser[]>;
  getRolePermissions(role: string): Promise<Record<string, unknown> | null>;
  getAccessGovernance?(role: string): Promise<{ active?: boolean; scopePolicy?: RoleScopePolicyOverride } | null>;
}

export class OrganizationalHierarchyError extends Error {
  constructor(public readonly code: string, public readonly httpStatus: number, message: string) {
    super(message);
  }
}

function active(user: OrganizationalUser): boolean {
  return user.isDeleted !== true && user.active !== false && user.loginAllowed !== false &&
    !["Inactive", "Archived", "Suspended"].includes(user.status || "") &&
    !["Inactive", "Archived", "Suspended"].includes(user.employmentStatus || "") &&
    user.accountStatus !== "INACTIVE";
}

function departmentFamily(user: OrganizationalUser): string {
  const explicit = String(user.department || "").trim().toLowerCase();
  if (explicit) return explicit;
  const role = user.role.toLowerCase();
  if (role.includes("medical")) return "medical";
  if (role.includes("sales") || role.includes("commercial")) return "sales";
  if (role.includes("marketing") || role.includes("product")) return "marketing";
  if (role.includes("finance") || role.includes("treasury")) return "finance";
  if (role.includes("warehouse") || role.includes("store") || role.includes("inventory")) return "warehouse";
  return "enterprise";
}

function inActorPolicy(
  actor: OrganizationalUser,
  target: OrganizationalUser,
  request: OrganizationalScopeRequest,
  policy: CanonicalRoleScopePolicy,
): boolean {
  const departmentRestricted = !policy.crossDepartment || request.departmentScope === "actor";
  if (departmentRestricted && departmentFamily(actor) !== departmentFamily(target)) return false;
  // Geography authorization is deliberately deferred to canonical territory
  // assignments. Profile/display country strings never widen hierarchy scope.
  return true;
}

function sortUsers(users: OrganizationalUser[]): OrganizationalUser[] {
  return [...users].sort((a, b) => a.id.localeCompare(b.id));
}

export async function resolveOrganizationalScope(
  verifiedActorUid: string | null | undefined,
  request: OrganizationalScopeRequest,
  repository: OrganizationalHierarchyRepository,
): Promise<OrganizationalScopeResult> {
  if (!verifiedActorUid) throw new OrganizationalHierarchyError("UNAUTHENTICATED", 401, "Authentication is required");
  if (request.actorUid && request.actorUid !== verifiedActorUid) {
    throw new OrganizationalHierarchyError("ACTOR_UID_MISMATCH", 403, "Requested actor does not match authenticated actor");
  }

  const actor = await repository.getUser(verifiedActorUid);
  if (!actor) throw new OrganizationalHierarchyError("ACTOR_NOT_FOUND", 403, "Authenticated user profile not found");
  if (!active(actor)) throw new OrganizationalHierarchyError("ACTOR_INACTIVE", 403, "Inactive actor cannot discover hierarchy");

  const [permissions, governance] = await Promise.all([
    repository.getRolePermissions(actor.role),
    repository.getAccessGovernance?.(actor.role) || Promise.resolve(null),
  ]);
  const scopePolicy = resolveRoleScopePolicy(
    actor.role,
    governance?.active === true ? governance.scopePolicy : null,
  );
  if (!scopePolicy) {
    throw new OrganizationalHierarchyError("ROLE_SCOPE_POLICY_INVALID", 403, "Canonical role scope policy is missing or invalid");
  }

  const depth = request.depth || scopePolicy.hierarchyDepth;
  const includeSelf = request.includeSelf !== false;
  const global = scopePolicy.subjectMode === "ORGANIZATION";
  const enumeratesOtherSubjects = depth !== "self"
    && (scopePolicy.subjectMode === "HIERARCHY" || scopePolicy.subjectMode === "ORGANIZATION");
  if (enumeratesOtherSubjects && permissions?.viewTeamData === false) {
    throw new OrganizationalHierarchyError("HIERARCHY_PERMISSION_DENIED", 403, "Role permission denies team hierarchy visibility");
  }
  const includeInactive = request.includeInactive === true && global;
  if (!global && depth !== "self" && !scopePolicy.descendantsContribute) {
    throw new OrganizationalHierarchyError("SUBORDINATE_ENUMERATION_DENIED", 403, "Actor role cannot enumerate subordinates");
  }

  let candidates: OrganizationalUser[] = [];
  let rawDirectIds = new Set<string>();
  if (depth !== "self") {
    if (global) {
      candidates = await repository.getAllUsers();
      rawDirectIds = new Set(candidates.filter((user) => user.managerId === actor.id).map((user) => user.id));
    } else {
      const queue = [actor.id];
      const expanded = new Set<string>();
      const discovered = new Set<string>([actor.id]);
      while (queue.length) {
        const managerUid = queue.shift()!;
        if (expanded.has(managerUid)) continue;
        expanded.add(managerUid);
        const reports = sortUsers(await repository.getDirectReports(managerUid));
        for (const report of reports) {
          if (!report.id || discovered.has(report.id)) continue;
          // An inactive relationship endpoint is neither visible nor a bridge
          // to otherwise active descendants.
          if (!active(report)) continue;
          discovered.add(report.id);
          candidates.push(report);
          if (managerUid === actor.id) rawDirectIds.add(report.id);
          if (depth === "descendants" && resolveRoleScopePolicy(report.role)?.descendantsContribute) queue.push(report.id);
        }
        if (depth === "direct") break;
      }
    }
  }

  const visible = sortUsers(candidates.filter((user) =>
    user.id !== actor.id && (includeInactive || active(user)) && inActorPolicy(actor, user, request, scopePolicy),
  ));
  const directReports = visible.filter((user) => rawDirectIds.has(user.id));
  const allHierarchyUsers = sortUsers(includeSelf ? [actor, ...visible] : visible);
  return {
    actor,
    directReports,
    descendants: visible,
    allHierarchyUsers,
    directReportUids: directReports.map((user) => user.id),
    descendantUids: visible.map((user) => user.id),
    allHierarchyUids: allHierarchyUsers.map((user) => user.id),
    scopePolicy,
  };
}
