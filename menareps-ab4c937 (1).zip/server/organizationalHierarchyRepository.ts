import { getFirebaseAdminServices } from "./firebaseAdmin";
import type { OrganizationalHierarchyRepository, OrganizationalUser } from "./organizationalHierarchyService";

export function createFirestoreOrganizationalHierarchyRepository(): OrganizationalHierarchyRepository {
  const db = getFirebaseAdminServices().db;
  return {
    async getUser(uid) {
      const snapshot = await db.collection("users").doc(uid).get();
      return snapshot.exists ? ({ ...snapshot.data(), id: snapshot.id } as OrganizationalUser) : null;
    },
    async getDirectReports(managerUid) {
      const snapshot = await db.collection("users").where("managerId", "==", managerUid).get();
      return snapshot.docs.map((document) => ({ ...document.data(), id: document.id } as OrganizationalUser));
    },
    async getAllUsers() {
      const snapshot = await db.collection("users").get();
      return snapshot.docs.map((document) => ({ ...document.data(), id: document.id } as OrganizationalUser));
    },
    async getRolePermissions(role) {
      const snapshot = await db.collection("rolePermissions").doc(role).get();
      return snapshot.exists ? (snapshot.data() || null) : null;
    },
    async getAccessGovernance(role) {
      const snapshot = await db.collection("accessGovernance").doc(role).get();
      return snapshot.exists ? (snapshot.data() || null) : null;
    },
  };
}
