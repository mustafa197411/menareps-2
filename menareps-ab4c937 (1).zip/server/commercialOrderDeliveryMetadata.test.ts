import { describe, expect, it } from "vitest";
import { canonicalDeliveryMetadata } from "./commercialOrderTransitionService";
import { applyOrderTransition } from "../src/features/orders/orderWorkflowEngine";

describe("WP110 canonical Delivery recipient persistence", () => {
  it("requires and sanitizes the governed recipient without accepting actor identity", () => {
    expect(canonicalDeliveryMetadata("DELIVERY_COMPLETE", {})).toEqual({ code: "DELIVERY_RECIPIENT_REQUIRED" });
    expect(canonicalDeliveryMetadata("DELIVERY_COMPLETE", {
      recipientName: "  Arbitrary Recipient  ",
      deliveredByUid: "forged-actor",
      deliverySignature: "recipient-signature",
    })).toEqual({ metadata: {
      recipientName: "Arbitrary Recipient",
      deliverySignature: "recipient-signature",
    } });
  });

  it("persists recipient and server actor through the terminal transition exactly once", () => {
    const result = applyOrderTransition({
      order: {
        id: "ORDER-A", displayNumber: "SO-A", status: "ASSIGNED_FOR_DELIVERY", stage: "DELIVERY",
        createdByUid: "REP-A", deliveryOfficerUid: "DELIVERY-A", history: [], total: 10,
      },
      action: "DELIVERY_COMPLETE",
      actor: { uid: "DELIVERY-A", role: "Delivery Officer", name: "Arbitrary Delivery Actor" },
      orderPermissions: ["ORDER_DELIVERY_COMPLETE"],
      metadata: { recipientName: "Arbitrary Recipient", deliveredByUid: "forged-actor" },
      source: "BACKEND",
    });
    expect(result.success).toBe(true);
    expect(result.updatedOrder).toMatchObject({
      status: "DELIVERED", stage: "CLOSED", recipientName: "Arbitrary Recipient", deliveredByUid: "DELIVERY-A",
    });
    expect(result.updatedOrder.history).toHaveLength(1);
    expect(result.updatedOrder.history[0]).toMatchObject({ action: "DELIVERY_COMPLETE", actorUid: "DELIVERY-A", toStatus: "DELIVERED", toStage: "CLOSED" });
  });

  it("denies an unrelated Delivery actor through segregation/assignment authority", () => {
    const result = applyOrderTransition({
      order: { id: "ORDER-A", status: "ASSIGNED_FOR_DELIVERY", createdByUid: "DELIVERY-B", deliveryOfficerUid: "DELIVERY-A", history: [] },
      action: "DELIVERY_COMPLETE",
      actor: { uid: "DELIVERY-B", role: "Delivery Officer" },
      orderPermissions: ["ORDER_DELIVERY_COMPLETE"],
      metadata: { recipientName: "Forged Recipient" },
    });
    expect(result.success).toBe(false);
    expect(result.reasonCode).toBe("SEGREGATION_OF_DUTIES_VIOLATION");
  });
});
