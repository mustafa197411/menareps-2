import { randomUUID } from "node:crypto";
import type { Firestore } from "firebase-admin/firestore";
import { getFirebaseAdminServices } from "./firebaseAdmin";
import { createFirestoreOperationalScopeRepository, resolveOperationalScopeForActor } from "./operationalScopeRepository";
import { normalizeRole, type Permissions } from "../src/types";
import {
  CANONICAL_OFFER_SCHEMA_VERSION,
  type CanonicalOfferDefinition,
  type OfferCapability,
  type OfferLifecycleStatus,
} from "../src/features/offers/types";
import { evaluateLifecycleTransition, evaluateMakerSeparation } from "../src/features/offers/offerPolicy";
import { adaptLegacyOfferForReadOnlyPresentation, validateCanonicalOfferDefinition } from "../src/features/offers/offerValidation";
import { hasOfferCapability, resolveOfferCapabilities } from "./offerAuthorization";
import {
  OfferCommercialRegistryError,
  resolveOfferCommercialOptions,
  resolveOfferCommercialContext,
  type OfferCommercialRegistryDependencies,
  type OfferCommercialRegistryErrorCode,
} from "./offerCommercialRegistryAdapter";

export const OFFER_COLLECTION = "offers" as const;

export type OfferAdministrationErrorCode =
  | "OFFER_AUTHENTICATION_REQUIRED" | "OFFER_ACTOR_NOT_FOUND" | "OFFER_ACTOR_INACTIVE"
  | "OFFER_PERMISSION_DENIED" | "OFFER_NOT_FOUND" | "OFFER_LEGACY_READ_ONLY"
  | "OFFER_UNSUPPORTED_SCHEMA" | "OFFER_INVALID_DEFINITION" | "OFFER_INVALID_TRANSITION"
  | "OFFER_CREATOR_APPROVER_CONFLICT" | "OFFER_STALE_REVISION" | "OFFER_PRODUCT_NOT_FOUND"
  | "OFFER_PRODUCT_INACTIVE" | "OFFER_PRODUCT_NOT_COMMERCIAL" | "OFFER_SCOPE_DENIED"
  | "OFFER_CANCELLATION_REASON_REQUIRED" | "OFFER_NOT_CURRENTLY_VALID"
  | "OFFER_INVALID_REQUEST" | "OFFER_MAKER_HISTORY_REQUIRED" | "OFFER_MAKER_APPROVER_CONFLICT"
  | OfferCommercialRegistryErrorCode
  | "OFFER_READ_FAILED" | "OFFER_WRITE_FAILED";

export class OfferAdministrationError extends Error {
  constructor(public readonly code: OfferAdministrationErrorCode, public readonly status: number, message: string = code) {
    super(message);
    this.name = "OfferAdministrationError";
  }
}

export interface OfferAdministrationScope {
  global: boolean;
  companyIds: string[];
  countryIds: string[];
  marketIds: string[];
  areaIds: string[];
  productIds: string[];
}

export interface OfferAdministrationActor {
  uid: string;
  role: string;
  permissions: Permissions | null;
  scope: OfferAdministrationScope;
}

export interface OfferAdministrationRepository {
  list(): Promise<Array<{ id: string; data: Record<string, unknown> }>>;
  get(id: string): Promise<Record<string, unknown> | null>;
  create(id: string, data: CanonicalOfferDefinition): Promise<void>;
  transact(id: string, expectedRevision: number, mutate: (current: Record<string, unknown>) => CanonicalOfferDefinition | Promise<CanonicalOfferDefinition>): Promise<CanonicalOfferDefinition>;
  getProduct(id: string): Promise<Record<string, unknown> | null>;
  getMarket(id: string): Promise<Record<string, unknown> | null>;
  getGeographyPath(areaId: string): Promise<{ countryId: string; districtId: string; cityId: string; areaId: string; active: boolean } | null>;
}

export type OfferDraftDefinitionInput = Pick<CanonicalOfferDefinition,
  "code" | "name" | "type" | "productScope" | "benefit" | "eligibility" | "stackingPolicy" | "usageLimits"
> & { nameAr?: string; description?: string; previousVersionId?: string };

export type OfferMutationCommand =
  | { action: "UPDATE_DRAFT"; offerId: string; expectedRevision: number; definition: OfferDraftDefinitionInput }
  | { action: "SUBMIT" | "RETURN_TO_DRAFT" | "APPROVE" | "ACTIVATE" | "PAUSE" | "REACTIVATE"; offerId: string; expectedRevision: number }
  | { action: "CANCEL"; offerId: string; expectedRevision: number; reason: string };

const text = (value: unknown): string => typeof value === "string" ? value.trim() : "";
const strings = (value: unknown): string[] => Array.isArray(value) ? Array.from(new Set(value.map(text).filter(Boolean))) : [];
const activeRecord = (data: Record<string, unknown>): boolean => data.active !== false && data.isActive !== false && data.status !== "Inactive" && data.status !== "Archived" && data.marketingStatus !== "Inactive";

function assertCapability(actor: OfferAdministrationActor, capability: OfferCapability): void {
  if (!hasOfferCapability(actor.role, actor.permissions, capability)) throw new OfferAdministrationError("OFFER_PERMISSION_DENIED", 403);
}

function assertRevision(value: unknown): asserts value is number {
  if (!Number.isSafeInteger(value) || Number(value) < 1) throw new OfferAdministrationError("OFFER_STALE_REVISION", 409);
}

function hasCompleteMakerHistory(data: Record<string, unknown>): boolean {
  return Array.isArray(data.makerIds) && data.makerIds.length > 0 && Array.isArray(data.makerAudit) && data.makerAudit.length > 0;
}

function canonicalExisting(data: Record<string, unknown>): CanonicalOfferDefinition {
  if (data.schemaVersion !== CANONICAL_OFFER_SCHEMA_VERSION) {
    throw new OfferAdministrationError(data.schemaVersion === undefined ? "OFFER_LEGACY_READ_ONLY" : "OFFER_UNSUPPORTED_SCHEMA", 409);
  }
  if (!hasCompleteMakerHistory(data)) {
    throw new OfferAdministrationError("OFFER_MAKER_HISTORY_REQUIRED", 409, "Offer has no complete immutable maker history and is read-only for mutations.");
  }
  const result = validateCanonicalOfferDefinition(data);
  if (!result.valid) throw new OfferAdministrationError("OFFER_INVALID_DEFINITION", 422);
  return result.value;
}

function withinScope(actor: OfferAdministrationActor, definition: Pick<CanonicalOfferDefinition, "eligibility" | "productScope" | "benefit">): boolean {
  if (actor.scope.global) return true;
  const { eligibility } = definition;
  if (!actor.scope.companyIds.includes(eligibility.companyId) || !actor.scope.countryIds.includes(eligibility.countryId)) return false;
  if (actor.scope.marketIds.length && !actor.scope.marketIds.includes(eligibility.marketId)) return false;
  if (eligibility.geographyPaths?.some(path => !actor.scope.areaIds.includes(path.areaId))) return false;
  const triggerIds = definition.productScope.mode === "SELECTED_PRODUCTS" ? definition.productScope.productIds : [];
  const rewardId = "reward" in definition.benefit && definition.benefit.reward.mode === "SELECTED_PRODUCT" ? definition.benefit.reward.rewardProductId : "";
  return actor.scope.productIds.length === 0 || [...triggerIds, rewardId].filter(Boolean).every(id => actor.scope.productIds.includes(id));
}

function rawWithinScope(actor: OfferAdministrationActor, data: Record<string, unknown>): boolean {
  if (actor.scope.global) return true;
  const eligibility = data.eligibility && typeof data.eligibility === "object" && !Array.isArray(data.eligibility) ? data.eligibility as Record<string, unknown> : {};
  const companyId = text(eligibility.companyId || data.companyId);
  const countryId = text(eligibility.countryId || data.countryId);
  return Boolean(companyId && countryId && actor.scope.companyIds.includes(companyId) && actor.scope.countryIds.includes(countryId));
}

async function validateGeography(repository: OfferAdministrationRepository, actor: OfferAdministrationActor, definition: CanonicalOfferDefinition): Promise<void> {
  if (!withinScope(actor, definition)) throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403);
  for (const path of definition.eligibility.geographyPaths || []) {
    const authoritative = await repository.getGeographyPath(path.areaId);
    if (!authoritative || !authoritative.active || ["countryId", "districtId", "cityId", "areaId"].some(key => authoritative[key as keyof typeof authoritative] !== path[key as keyof typeof path])) {
      throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403, "Offer geography path is not canonical or active.");
    }
  }
}

async function canonicalCommercial(
  actor: OfferAdministrationActor,
  definition: Pick<CanonicalOfferDefinition, "eligibility" | "productScope" | "benefit">,
  dependencies: OfferCommercialRegistryDependencies,
  now: string,
) {
  try { return await resolveOfferCommercialContext(actor.scope, definition, dependencies, now); }
  catch (error) {
    if (error instanceof OfferCommercialRegistryError) throw new OfferAdministrationError(error.code, error.status);
    throw error;
  }
}

function buildDefinition(id: string, input: OfferDraftDefinitionInput, actorUid: string, now: string, commercial: Awaited<ReturnType<typeof canonicalCommercial>>, current?: CanonicalOfferDefinition): CanonicalOfferDefinition {
  const revision = current ? current.revision + 1 : 1;
  const makerIds = Array.from(new Set([...(current?.makerIds || []), actorUid]));
  const makerAudit = [...(current?.makerAudit || []), { actorId: actorUid, action: current ? "EDIT" as const : "CREATE" as const, occurredAt: now, revision }];
  const value = {
    id,
    schemaVersion: CANONICAL_OFFER_SCHEMA_VERSION,
    offerVersion: current?.offerVersion ?? 1,
    code: input.code,
    name: input.name,
    ...(input.nameAr ? { nameAr: input.nameAr } : {}),
    ...(input.description ? { description: input.description } : {}),
    type: input.type,
    lifecycleStatus: "DRAFT",
    productScope: input.productScope,
    benefit: input.benefit,
    eligibility: commercial.eligibility,
    commercialContext: commercial.commercialContext,
    stackingPolicy: input.stackingPolicy,
    ...(input.usageLimits ? { usageLimits: input.usageLimits } : {}),
    createdAt: current?.createdAt ?? now,
    createdBy: current?.createdBy ?? actorUid,
    updatedAt: now,
    updatedBy: actorUid,
    makerIds,
    makerAudit,
    ...(current?.previousVersionId || input.previousVersionId ? { previousVersionId: current?.previousVersionId || input.previousVersionId } : {}),
    revision,
  } as CanonicalOfferDefinition;
  const result = validateCanonicalOfferDefinition(value);
  if (!result.valid) throw new OfferAdministrationError("OFFER_INVALID_DEFINITION", 422, result.errors.map(error => `${error.path}:${error.code}`).join(","));
  return result.value;
}

export async function createOfferDraft(
  actor: OfferAdministrationActor,
  input: OfferDraftDefinitionInput,
  repository: OfferAdministrationRepository,
  commercialDependencies: OfferCommercialRegistryDependencies,
  options: { id?: string; now?: string } = {},
): Promise<CanonicalOfferDefinition> {
  assertCapability(actor, "offers.create");
  const id = options.id || `OFR-${randomUUID()}`;
  const now = options.now || commercialDependencies.clock();
  const commercial = await canonicalCommercial(actor, input as CanonicalOfferDefinition, commercialDependencies, now);
  const offer = buildDefinition(id, input, actor.uid, now, commercial);
  await validateGeography(repository, actor, offer);
  await repository.create(id, offer);
  return offer;
}

export async function readOfferCommercialOptions(actor: OfferAdministrationActor, commercialDependencies: OfferCommercialRegistryDependencies) {
  assertCapability(actor, "offers.view");
  try { return await resolveOfferCommercialOptions(actor.scope, commercialDependencies); }
  catch (error) {
    if (error instanceof OfferCommercialRegistryError) throw new OfferAdministrationError(error.code, error.status);
    throw error;
  }
}

function lifecycle(current: CanonicalOfferDefinition, to: OfferLifecycleStatus): void {
  if (!evaluateLifecycleTransition(current.lifecycleStatus, to).valid) throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409);
}

export async function mutateOffer(
  actor: OfferAdministrationActor,
  command: OfferMutationCommand,
  repository: OfferAdministrationRepository,
  commercialDependencies: OfferCommercialRegistryDependencies,
  options: { now?: string } = {},
): Promise<CanonicalOfferDefinition> {
  assertRevision(command.expectedRevision);
  const capabilities: Record<OfferMutationCommand["action"], OfferCapability> = {
    UPDATE_DRAFT: "offers.editDraft", SUBMIT: "offers.submit", RETURN_TO_DRAFT: "offers.approve", APPROVE: "offers.approve",
    ACTIVATE: "offers.activate", PAUSE: "offers.pause", REACTIVATE: "offers.activate", CANCEL: "offers.cancel",
  };
  assertCapability(actor, capabilities[command.action]);
  const now = options.now || commercialDependencies.clock();
  return repository.transact(command.offerId, command.expectedRevision, async currentData => {
    let current = canonicalExisting(currentData);
    if (!withinScope(actor, current)) throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403);
    if (command.action === "UPDATE_DRAFT") {
      if (current.lifecycleStatus !== "DRAFT") throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409);
      const commercial = await canonicalCommercial(actor, command.definition as CanonicalOfferDefinition, commercialDependencies, now);
      const updated = buildDefinition(current.id, command.definition, actor.uid, now, commercial, current);
      await validateGeography(repository, actor, updated);
      return updated;
    }
    if (["SUBMIT", "APPROVE", "ACTIVATE", "REACTIVATE"].includes(command.action)) {
      const commercial = await canonicalCommercial(actor, current, commercialDependencies, now);
      current = { ...current, eligibility: commercial.eligibility, commercialContext: commercial.commercialContext };
    }
    let next: CanonicalOfferDefinition = { ...current, updatedAt: now, updatedBy: actor.uid, revision: current.revision + 1 };
    if (command.action === "SUBMIT") {
      lifecycle(current, "PENDING_APPROVAL");
      next = {
        ...next,
        lifecycleStatus: "PENDING_APPROVAL",
        submittedAt: now,
        submittedBy: actor.uid,
        makerIds: Array.from(new Set([...(current.makerIds || []), actor.uid])),
        makerAudit: [...(current.makerAudit || []), { actorId: actor.uid, action: "SUBMIT", occurredAt: now, revision: next.revision }],
      };
    } else if (command.action === "RETURN_TO_DRAFT") {
      lifecycle(current, "DRAFT");
      const { approvedAt: _a, approvedBy: _b, scheduledAt: _s, scheduledBy: _sb, activatedAt: _c, activatedBy: _d, ...rest } = next;
      next = { ...rest, lifecycleStatus: "DRAFT" } as CanonicalOfferDefinition;
    } else if (command.action === "APPROVE") {
      if (current.lifecycleStatus !== "PENDING_APPROVAL") throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409);
      if (current.approvedAt || current.approvedBy) throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409, "Offer is already approved.");
      if (!evaluateMakerSeparation(current.makerIds || [], actor.uid).valid) throw new OfferAdministrationError("OFFER_MAKER_APPROVER_CONFLICT", 409);
      next = { ...next, approvedAt: now, approvedBy: actor.uid };
    } else if (command.action === "ACTIVATE") {
      if (!current.approvedAt || !current.approvedBy) throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409, "Approval is required before activation.");
      if (!evaluateMakerSeparation(current.makerIds || [], actor.uid).valid) throw new OfferAdministrationError("OFFER_MAKER_APPROVER_CONFLICT", 409);
      const instant = Date.parse(now);
      const start = Date.parse(current.eligibility.startAt), end = Date.parse(current.eligibility.endAt);
      if (instant > end) throw new OfferAdministrationError("OFFER_NOT_CURRENTLY_VALID", 409);
      const target = instant < start ? "SCHEDULED" : "ACTIVE";
      lifecycle(current, target);
      await validateGeography(repository, actor, current);
      next = target === "SCHEDULED"
        ? { ...next, lifecycleStatus: target, scheduledAt: now, scheduledBy: actor.uid }
        : { ...next, lifecycleStatus: target, activatedAt: now, activatedBy: actor.uid };
    } else if (command.action === "PAUSE") {
      lifecycle(current, "PAUSED");
      next = { ...next, lifecycleStatus: "PAUSED", pausedAt: now, pausedBy: actor.uid };
    } else if (command.action === "REACTIVATE") {
      lifecycle(current, "ACTIVE");
      if (!current.approvedAt || !current.approvedBy) throw new OfferAdministrationError("OFFER_INVALID_TRANSITION", 409);
      if (!evaluateMakerSeparation(current.makerIds || [], actor.uid).valid) throw new OfferAdministrationError("OFFER_MAKER_APPROVER_CONFLICT", 409);
      if (Date.parse(now) < Date.parse(current.eligibility.startAt) || Date.parse(now) > Date.parse(current.eligibility.endAt)) throw new OfferAdministrationError("OFFER_NOT_CURRENTLY_VALID", 409);
      await validateGeography(repository, actor, current);
      next = { ...next, lifecycleStatus: "ACTIVE", activatedAt: now, activatedBy: actor.uid };
    } else {
      const reason = "reason" in command ? command.reason : "";
      if (!text(reason)) throw new OfferAdministrationError("OFFER_CANCELLATION_REASON_REQUIRED", 422);
      lifecycle(current, "CANCELLED");
      next = { ...next, lifecycleStatus: "CANCELLED", cancelledAt: now, cancelledBy: actor.uid, cancellationReason: text(reason) };
    }
    const result = validateCanonicalOfferDefinition(next);
    if (!result.valid) throw new OfferAdministrationError("OFFER_INVALID_DEFINITION", 422);
    return result.value;
  });
}

export type OfferReadRecord =
  | { kind: "CANONICAL"; offer: CanonicalOfferDefinition }
  | { kind: "LEGACY"; offer: ReturnType<typeof adaptLegacyOfferForReadOnlyPresentation> extends { valid: true; value: infer T } ? T : never };

function readRecord(id: string, data: Record<string, unknown>): OfferReadRecord {
  const withId = { ...data, id };
  if (data.schemaVersion === CANONICAL_OFFER_SCHEMA_VERSION && !hasCompleteMakerHistory(data)) {
    const legacy = adaptLegacyOfferForReadOnlyPresentation(withId);
    return { kind: "LEGACY", offer: legacy.valid ? legacy.value : { id, name: "Legacy Offer", legacyTypeLabel: text(data.type) || "Unknown Legacy Offer Type", status: "READ_ONLY_LEGACY", operationallyApplicable: false, canEdit: false, canDelete: false, canActivate: false } } as OfferReadRecord;
  }
  const validation = validateCanonicalOfferDefinition(withId);
  if (validation.valid) return { kind: "CANONICAL", offer: validation.value };
  const legacy = adaptLegacyOfferForReadOnlyPresentation(withId);
  return { kind: "LEGACY", offer: legacy.valid ? legacy.value : { id, name: "Legacy Offer", legacyTypeLabel: text(data.type) || "Unknown Legacy Offer Type", status: "READ_ONLY_LEGACY", operationallyApplicable: false, canEdit: false, canDelete: false, canActivate: false } } as OfferReadRecord;
}

export async function listOffers(actor: OfferAdministrationActor, repository: OfferAdministrationRepository): Promise<OfferReadRecord[]> {
  assertCapability(actor, "offers.view");
  const documents = await repository.list();
  return documents.filter(document => rawWithinScope(actor, document.data)).map(document => readRecord(document.id, document.data)).filter(record => record.kind === "LEGACY" || withinScope(actor, record.offer));
}

export async function readOffer(actor: OfferAdministrationActor, id: string, repository: OfferAdministrationRepository): Promise<OfferReadRecord> {
  assertCapability(actor, "offers.view");
  const data = await repository.get(id);
  if (!data) throw new OfferAdministrationError("OFFER_NOT_FOUND", 404);
  if (!rawWithinScope(actor, data)) throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403);
  const result = readRecord(id, data);
  if (result.kind === "CANONICAL" && !withinScope(actor, result.offer)) throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403);
  return result;
}

export function createFirestoreOfferRepository(db: Firestore = getFirebaseAdminServices().db): OfferAdministrationRepository {
  return {
    async list() { const snapshot = await db.collection(OFFER_COLLECTION).get(); return snapshot.docs.map(doc => ({ id: doc.id, data: doc.data() })); },
    async get(id) { const snapshot = await db.collection(OFFER_COLLECTION).doc(id).get(); return snapshot.exists ? snapshot.data() || null : null; },
    async create(id, data) { await db.collection(OFFER_COLLECTION).doc(id).create(data); },
    async transact(id, expectedRevision, mutate) {
      return db.runTransaction(async transaction => {
        const reference = db.collection(OFFER_COLLECTION).doc(id);
        const snapshot = await transaction.get(reference);
        if (!snapshot.exists) throw new OfferAdministrationError("OFFER_NOT_FOUND", 404);
        const current = snapshot.data() || {};
        if (current.schemaVersion !== CANONICAL_OFFER_SCHEMA_VERSION) return await mutate(current);
        if (current.revision !== expectedRevision) throw new OfferAdministrationError("OFFER_STALE_REVISION", 409);
        const next = await mutate(current);
        transaction.set(reference, next);
        return next;
      });
    },
    async getProduct(id) { const snapshot = await db.collection("products").doc(id).get(); return snapshot.exists ? snapshot.data() || null : null; },
    async getMarket(id) { const snapshot = await db.collection("marketSettings").doc(id).get(); return snapshot.exists ? snapshot.data() || null : null; },
    async getGeographyPath(areaId) {
      const areaSnap = await db.collection("areas").doc(areaId).get();
      if (!areaSnap.exists) return null;
      const area = areaSnap.data() || {};
      return { countryId: text(area.countryId), districtId: text(area.districtId), cityId: text(area.cityId), areaId, active: activeRecord(area) };
    },
  };
}

export async function resolveOfferAdministrationActor(uid: string, user: Record<string, unknown>, db: Firestore = getFirebaseAdminServices().db): Promise<OfferAdministrationActor> {
  const role = validateOfferActorProfile(uid, user);
  const permissionSnapshot = await db.collection("rolePermissions").doc(role).get();
  const permissions = permissionSnapshot.exists ? permissionSnapshot.data() as Permissions : null;
  const operational = await resolveOperationalScopeForActor(uid, {}, createFirestoreOperationalScopeRepository());
  if (!operational.authorized) throw new OfferAdministrationError("OFFER_SCOPE_DENIED", 403);
  const companies = strings(user.companyIds || user.assignedCompanies || [user.companyId || user.company]);
  return {
    uid, role, permissions,
    scope: {
      global: operational.subjectMode === "ORGANIZATION",
      companyIds: companies,
      countryIds: operational.countryIds,
      marketIds: strings(user.marketIds || user.assignedMarkets),
      areaIds: operational.areaIds,
      productIds: operational.productIds,
    },
  };
}

export function validateOfferActorProfile(uid: string, user: Record<string, unknown> | null | undefined): string {
  if (!uid) throw new OfferAdministrationError("OFFER_AUTHENTICATION_REQUIRED", 401);
  if (!user) throw new OfferAdministrationError("OFFER_ACTOR_NOT_FOUND", 403);
  if (user.active === false || user.loginAllowed === false || user.isDeleted === true || ["Inactive", "Suspended", "Archived"].includes(text(user.status) || text(user.employmentStatus))) throw new OfferAdministrationError("OFFER_ACTOR_INACTIVE", 403);
  return String(normalizeRole(text(user.role)));
}

export function offerAdministrationResponse(actor: OfferAdministrationActor) {
  return {
    capabilities: resolveOfferCapabilities(actor.role, actor.permissions),
    authorizedScope: {
      companyIds: actor.scope.companyIds,
      countryIds: actor.scope.countryIds,
      marketIds: actor.scope.marketIds,
    },
  };
}
