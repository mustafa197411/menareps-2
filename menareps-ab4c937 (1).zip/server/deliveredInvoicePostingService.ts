import { Role, normalizeRole } from "../src/types";
import { calculateDueDate, generateCustomerAccountNumber } from "../src/features/ar/arResolvers";
import {
  createFirestoreDeliveredInvoicePostingRepository,
  type DeliveredInvoicePostingRepository,
} from "./deliveredInvoicePostingRepository";
import { resolveFinancialIdentity } from "../src/lib/financialIdentity";
import { validateMarketSettings, type MarketBusinessSettings } from "../src/lib/marketSettings";

export interface DeliveredInvoicePostRequest { orderId: string }
export interface DeliveredInvoicePostResult {
  success: boolean; posted: boolean; code?: string; orderId?: string; invoiceId?: string; ledgerEntryId?: string;
}

interface Dependencies { repository: DeliveredInvoicePostingRepository; now(): string }
const text = (value: unknown) => typeof value === "string" ? value.trim() : "";

export function parseDeliveredInvoicePostRequest(input: unknown): DeliveredInvoicePostRequest | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const body = input as Record<string, unknown>;
  if (Object.keys(body).some((key) => key !== "orderId")) return null;
  const orderId = text(body.orderId);
  return orderId && orderId.length <= 512 ? { orderId } : null;
}

function actorOperational(actor: Record<string, any> | null): boolean {
  const statuses = [actor?.status, actor?.accountStatus, actor?.employmentStatus]
    .map((value) => text(value).toUpperCase()).filter(Boolean);
  return Boolean(actor) && actor!.active !== false && actor!.loginAllowed === true && actor!.isDeleted !== true
    && statuses.every((status) => status === "ACTIVE" || status === "OPERATIONAL");
}

function safePart(value: string): string { return value.replace(/[^a-zA-Z0-9_-]/g, "_"); }

export async function postDeliveredInvoiceServer(
  authenticatedActorUid: string,
  request: DeliveredInvoicePostRequest,
  overrides?: Partial<Dependencies>,
): Promise<DeliveredInvoicePostResult> {
  const deps: Dependencies = {
    repository: overrides?.repository || createFirestoreDeliveredInvoicePostingRepository(),
    now: overrides?.now || (() => new Date().toISOString()),
  };
  return deps.repository.runTransaction(authenticatedActorUid, request.orderId, async (context) => {
    if (!actorOperational(context.actor)) return { success: false, posted: false, code: context.actor ? "ACTOR_INACTIVE" : "ACTOR_NOT_FOUND" };
    if (!context.order) return { success: false, posted: false, code: "ORDER_NOT_FOUND" };
    const order = context.order;
    const invoiceId = text(order.invoiceNumber) || text(order.commercialInvoiceNumber) || text(order.invoiceId) || `INV-${text(order.displayNumber) || order.id}`;
    const ledgerEntryId = context.ledgerId;
    const role = normalizeRole(context.actor.role);
    const assignedDeliveryActor = role === Role.DELIVERY_OFFICER && text(order.deliveryOfficerUid) === authenticatedActorUid;
    const privilegedActor = [Role.FINANCE, Role.ADMIN, Role.SUPER_ADMIN, Role.GENERAL_MANAGER].includes(role as Role);
    if (!assignedDeliveryActor && !privilegedActor) return { success: false, posted: false, code: "ACTOR_NOT_AUTHORIZED" };
    if (text(order.status).toUpperCase() !== "DELIVERED" || text(order.stage).toUpperCase() !== "CLOSED") {
      return { success: false, posted: false, code: "ORDER_NOT_DELIVERED" };
    }
    if (context.existingLedger) return { success: true, posted: false, code: "ALREADY_POSTED", orderId: order.id, invoiceId, ledgerEntryId };
    const pharmacyId = text(order.pharmacyId) || text(order.pharmacy);
    const amount = Number(order.grandTotal ?? order.total ?? order.netTotal ?? order.totalAmount ?? order.subtotal ?? 0);
    if (!pharmacyId) return { success: false, posted: false, code: "MISSING_PHARMACY_ID" };
    if (!(amount > 0)) return { success: false, posted: false, code: "INVALID_AMOUNT" };
    const market = context.market as unknown as MarketBusinessSettings | null;
    if (!market || market.active !== true || validateMarketSettings(market).length > 0) {
      return { success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" };
    }
    const financialIdentity = resolveFinancialIdentity(
      [order, context.profile || {}, context.pharmacy || {}] as Array<Record<string, unknown>>,
      [market],
    );
    if (!financialIdentity) return { success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" };
    const now = deps.now();
    const postingDate = text(order.deliveredAt || order.date || order.createdAt || now).slice(0, 10);
    const paymentTermCode = context.profile?.paymentTermCode || "CASH";
    const paymentTermDays = Number(context.profile?.paymentTermDays ?? 0);
    const accountNumber = context.profile?.customerAccountNumber || generateCustomerAccountNumber({ ...(context.pharmacy || {}), ...financialIdentity, id: pharmacyId }, [market]);
    const ledger = {
      id: ledgerEntryId, pharmacyId, customerAccountNumber: accountNumber, orderId: order.id,
      orderNumber: text(order.displayNumber) || text(order.orderNumber) || order.id,
      invoiceId, invoiceNumber: invoiceId, transactionType: "INVOICE", sourceType: "DELIVERED_ORDER", sourceId: order.id,
      description: `Commercial Invoice ${invoiceId} for Delivered Order #${text(order.displayNumber) || order.id}`,
      debitAmount: amount, creditAmount: 0, netAmount: amount, currency: financialIdentity.currencyCode, currencyCode: financialIdentity.currencyCode, marketId: financialIdentity.marketId, countryId: financialIdentity.countryId, postingDate,
      dueDate: calculateDueDate(postingDate, paymentTermCode, paymentTermDays),
      paymentTermCodeSnapshot: paymentTermCode, paymentTermDaysSnapshot: paymentTermDays,
      invoiceOriginalAmount: amount, invoiceAppliedAmount: 0, invoiceOpenAmount: amount,
      status: "POSTED", isReversal: false, reversesEntryId: null,
      idempotencyKey: `DELIVERED_INVOICE_${order.id}_${invoiceId}`,
      createdAt: now, createdByUid: authenticatedActorUid,
      createdByName: text(context.actor.name) || text(context.actor.fullName) || text(context.actor.email),
    };
    const existing: Record<string, any> = context.profile || {};
    const profile = {
      ...(!context.profile ? {
        pharmacyId, pharmacyName: context.pharmacy?.name || context.pharmacy?.pharmacyName || `Pharmacy ${pharmacyId.slice(-4)}`,
        customerAccountNumber: accountNumber, currency: financialIdentity.currencyCode, currencyCode: financialIdentity.currencyCode, marketId: financialIdentity.marketId, countryId: financialIdentity.countryId, paymentTermCode, paymentTermDays,
        openingBalance: 0, overdueBalance: 0, totalCollected: 0, paidInvoiceCount: 0,
        oldestOpenInvoiceDate: postingDate, active: true, createdAt: now, createdByUid: authenticatedActorUid,
      } : {}),
      outstandingBalance: Number(existing.outstandingBalance || 0) + amount,
      totalInvoiced: Number(existing.totalInvoiced || 0) + amount,
      openInvoiceCount: Number(existing.openInvoiceCount || 0) + 1,
      lastInvoiceDate: postingDate, lastLedgerActivityAt: now, updatedAt: now, updatedByUid: authenticatedActorUid,
    };
    context.create(ledger, profile);
    return { success: true, posted: true, orderId: order.id, invoiceId, ledgerEntryId };
  });
}
