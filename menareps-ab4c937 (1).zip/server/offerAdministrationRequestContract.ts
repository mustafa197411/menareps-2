import type { OfferDraftDefinitionInput, OfferMutationCommand } from "./offerAdministrationService";

type DataRecord = Record<string, unknown>;
const record = (value: unknown): DataRecord | null => value !== null && typeof value === "object" && !Array.isArray(value) ? value as DataRecord : null;
const ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/;
const exactId = (value: unknown): value is string => typeof value === "string" && value === value.trim() && ID.test(value);
const exactKeys = (value: DataRecord, allowed: readonly string[]): boolean => Object.keys(value).every(key => allowed.includes(key));
const idArray = (value: unknown): boolean => Array.isArray(value) && value.every(exactId) && new Set(value).size === value.length;

function validReward(value: unknown): boolean {
  const reward = record(value);
  return Boolean(reward && exactKeys(reward, ["mode", "rewardProductId"]) &&
    (reward.mode === "SAME_AS_TRIGGER" ? !("rewardProductId" in reward) : reward.mode === "SELECTED_PRODUCT" && exactId(reward.rewardProductId)));
}

function validBenefit(value: unknown): boolean {
  const benefit = record(value);
  if (!benefit || typeof benefit.kind !== "string") return false;
  if (benefit.kind === "PRODUCT_PERCENTAGE") return exactKeys(benefit, ["kind", "percentage", "base"]);
  if (benefit.kind === "INVOICE_PERCENTAGE") return exactKeys(benefit, ["kind", "percentage", "base", "excludesFreeLines", "excludesProductsOutsideScope"]);
  if (benefit.kind === "BUY_X_GET_Y") return exactKeys(benefit, ["kind", "buyQuantity", "freeQuantity", "reward", "aggregationMode", "multiples", "remainder"]) && validReward(benefit.reward);
  if (benefit.kind !== "TIER_BONUS" || !exactKeys(benefit, ["kind", "tiers", "reward", "aggregationMode", "applicationMode"]) || !validReward(benefit.reward) || !Array.isArray(benefit.tiers)) return false;
  return benefit.tiers.every(value => { const tier = record(value); return Boolean(tier && exactKeys(tier, ["buyQuantity", "freeQuantity"])); });
}

function validEligibility(value: unknown): boolean {
  const eligibility = record(value);
  if (!eligibility || !exactKeys(eligibility, ["companyMarketId", "companyId", "marketId", "countryId", "geographyPaths", "pharmacyIds", "pharmacyTypes", "startAt", "endAt", "productVerificationPolicy", "marketTimePolicy"])) return false;
  const relationshipId = exactId(eligibility.companyMarketId);
  const explicitPair = exactId(eligibility.companyId) && exactId(eligibility.marketId);
  if (relationshipId === explicitPair) return false;
  if (eligibility.marketId !== undefined && !exactId(eligibility.marketId)) return false;
  if (eligibility.countryId !== undefined && !exactId(eligibility.countryId)) return false;
  if (eligibility.geographyPaths !== undefined && (!Array.isArray(eligibility.geographyPaths) || eligibility.geographyPaths.some(value => {
    const path = record(value);
    return !path || !exactKeys(path, ["countryId", "districtId", "cityId", "areaId"]) || ![path.countryId, path.districtId, path.cityId, path.areaId].every(exactId);
  }))) return false;
  return (eligibility.pharmacyIds === undefined || idArray(eligibility.pharmacyIds)) && (eligibility.pharmacyTypes === undefined || idArray(eligibility.pharmacyTypes));
}

export function parseOfferDraftRequest(value: unknown): OfferDraftDefinitionInput | null {
  const wrapper = record(value);
  const input = record(wrapper?.definition);
  if (!wrapper || !input || !exactKeys(wrapper, ["definition"]) || !exactKeys(input, ["code", "name", "nameAr", "description", "previousVersionId", "type", "productScope", "benefit", "eligibility", "stackingPolicy", "usageLimits"])) return null;
  const productScope = record(input.productScope), stacking = record(input.stackingPolicy), limits = input.usageLimits === undefined ? undefined : record(input.usageLimits);
  if (!productScope || !exactKeys(productScope, ["mode", "productIds"]) || !idArray(productScope.productIds)) return null;
  if (!validBenefit(input.benefit) || !validEligibility(input.eligibility)) return null;
  if (!stacking || !exactKeys(stacking, ["mode", "priority", "compatibleCombination", "maximumProductOrQuantityOffersPerPaidLine", "maximumInvoicePercentageOffersPerInvoice"])) return null;
  if (input.usageLimits !== undefined && !limits) return null;
  if (limits && !exactKeys(limits, ["perPharmacy", "campaignTotal"])) return null;
  return input as unknown as OfferDraftDefinitionInput;
}

export function parseOfferMutationRequest(value: unknown): OfferMutationCommand | null {
  const command = record(value);
  if (!command || !exactId(command.offerId) || !Number.isSafeInteger(command.expectedRevision)) return null;
  if (command.action === "UPDATE_DRAFT") {
    if (!exactKeys(command, ["action", "offerId", "expectedRevision", "definition"])) return null;
    const definition = parseOfferDraftRequest({ definition: command.definition });
    return definition ? { action: "UPDATE_DRAFT", offerId: command.offerId, expectedRevision: Number(command.expectedRevision), definition } : null;
  }
  if (command.action === "CANCEL") return exactKeys(command, ["action", "offerId", "expectedRevision", "reason"]) && typeof command.reason === "string"
    ? command as unknown as OfferMutationCommand : null;
  const actions = ["SUBMIT", "RETURN_TO_DRAFT", "APPROVE", "ACTIVATE", "PAUSE", "REACTIVATE"];
  return actions.includes(String(command.action)) && exactKeys(command, ["action", "offerId", "expectedRevision"])
    ? command as unknown as OfferMutationCommand : null;
}
