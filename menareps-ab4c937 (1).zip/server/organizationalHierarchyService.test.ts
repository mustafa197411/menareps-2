import { strict as assert } from "node:assert";
import {
  OrganizationalHierarchyError,
  OrganizationalHierarchyRepository,
  OrganizationalUser,
  resolveOrganizationalScope,
} from "./organizationalHierarchyService";

const u = (id: string, role: string, managerId = "", extra: Partial<OrganizationalUser> = {}): OrganizationalUser => ({
  id, role, managerId, active: true, loginAllowed: true, country: "Libya", ...extra,
});

const tree: OrganizationalUser[] = [
  u("admin", "Admin"),
  u("gm", "General Manager", "admin"),
  u("regional", "Regional Manager", "gm"),
  u("country", "Country Manager", "regional"),
  u("medical-manager", "Medical Manager", "country"),
  u("medical-supervisor", "Medical Supervisor", "medical-manager"),
  u("medical-rep", "Medical Representative", "medical-supervisor"),
  u("medical-sibling-supervisor", "Medical Supervisor", "medical-manager"),
  u("medical-sibling-rep", "Medical Representative", "medical-sibling-supervisor"),
  u("sales-manager", "Sales Manager", "country"),
  u("sales-supervisor", "Sales Supervisor", "sales-manager"),
  u("sales-rep", "Sales Representative", "sales-supervisor"),
  u("tunisia-manager", "Sales Manager", "country", { country: "Tunisia" }),
  u("tunisia-rep", "Sales Representative", "tunisia-manager", { country: "Tunisia" }),
  u("unrelated-manager", "Medical Manager"),
  u("unrelated-rep", "Medical Representative", "unrelated-manager"),
];

function repository(records = tree, permissions: Record<string, Record<string, unknown>> = {}): OrganizationalHierarchyRepository {
  return {
    async getUser(uid) { return records.find((record) => record.id === uid) || null; },
    async getDirectReports(managerUid) { return records.filter((record) => record.managerId === managerUid); },
    async getAllUsers() { return [...records]; },
    async getRolePermissions(role) { return permissions[role] || null; },
  };
}

const resolve = (actorUid: string, request = {}, repo = repository()) =>
  resolveOrganizationalScope(actorUid, { depth: "descendants", includeSelf: true, ...request }, repo);

const supervisor = await resolve("medical-supervisor");
assert.deepEqual(supervisor.directReportUids, ["medical-rep"]);
assert.deepEqual(supervisor.descendantUids, ["medical-rep"]);
assert(!supervisor.descendantUids.includes("medical-sibling-rep"));

const medicalManager = await resolve("medical-manager");
assert(medicalManager.descendantUids.includes("medical-supervisor"));
assert(medicalManager.descendantUids.includes("medical-rep"));
assert(!medicalManager.descendantUids.includes("sales-manager"));

const salesManager = await resolve("sales-manager");
assert.deepEqual(salesManager.descendantUids, ["sales-rep", "sales-supervisor"]);

const gm = await resolve("gm");
assert(gm.descendantUids.includes("medical-rep"));
assert(gm.descendantUids.includes("sales-rep"));

const country = await resolve("country");
assert(country.descendantUids.includes("medical-rep"));
assert(country.descendantUids.includes("sales-rep"));
// Profile/display country strings are not authorization boundaries. Canonical
// territory ancestry is applied by the operational-scope resolver.
assert(country.descendantUids.includes("tunisia-manager"));
assert(country.descendantUids.includes("tunisia-rep"));

const regional = await resolve("regional");
assert(regional.descendantUids.includes("country"));
assert(regional.descendantUids.includes("medical-rep"));

const admin = await resolve("admin");
assert(admin.descendantUids.includes("unrelated-manager"));
assert(admin.descendantUids.includes("tunisia-rep"));

for (const [role, reportRole] of [
  ["Super Admin", "Medical Representative"],
  ["Sales & Marketing Manager", "Marketing Officer"],
  ["Area Sales Manager", "Sales Representative"],
  ["Sales Supervisor", "Sales Representative"],
  ["Marketing Manager", "Marketing Officer"],
] as const) {
  const manager = u(`coverage-${role}`, role);
  const report = u(`coverage-report-${role}`, reportRole, manager.id);
  const coverage = await resolveOrganizationalScope(manager.id, { depth: "descendants" }, repository([manager, report]));
  assert(coverage.descendantUids.includes(report.id), `${role} must use the canonical shared architecture`);
}

for (const role of ["Product Manager", "Finance Manager", "Warehouse Manager", "Store Manager"] as const) {
  const actor = u(`non-hierarchy-${role}`, role);
  const report = u(`non-hierarchy-report-${role}`, "Medical Representative", actor.id);
  await assert.rejects(
    () => resolveOrganizationalScope(actor.id, { depth: "descendants" }, repository([actor, report])),
    (error: OrganizationalHierarchyError) => error.code === "SUBORDINATE_ENUMERATION_DENIED",
  );
}

const inactiveBridge = [
  u("bridge-med-manager", "Medical Manager"),
  u("bridge-med-supervisor", "Medical Supervisor", "bridge-med-manager", { active: false }),
  u("bridge-med-rep", "Medical Representative", "bridge-med-supervisor"),
  u("bridge-sales-manager", "Sales Manager"),
  u("bridge-sales-supervisor", "Sales Supervisor", "bridge-sales-manager", { active: false }),
  u("bridge-sales-rep", "Sales Representative", "bridge-sales-supervisor"),
];
const medicalBridge = await resolve("bridge-med-manager", {}, repository(inactiveBridge));
assert.deepEqual(medicalBridge.descendantUids, []);
const salesBridge = await resolve("bridge-sales-manager", {}, repository(inactiveBridge));
assert.deepEqual(salesBridge.descendantUids, []);

await assert.rejects(() => resolve("medical-rep"), (error: OrganizationalHierarchyError) => error.code === "SUBORDINATE_ENUMERATION_DENIED");
await assert.rejects(
  () => resolveOrganizationalScope("medical-manager", { actorUid: "unrelated-manager" }, repository()),
  (error: OrganizationalHierarchyError) => error.code === "ACTOR_UID_MISMATCH",
);
await assert.rejects(
  () => resolveOrganizationalScope(null, {}, repository()),
  (error: OrganizationalHierarchyError) => error.code === "UNAUTHENTICATED",
);
await assert.rejects(
  () => resolve("medical-manager", {}, repository(tree.map((record) => record.id === "medical-manager" ? { ...record, active: false } : record))),
  (error: OrganizationalHierarchyError) => error.code === "ACTOR_INACTIVE",
);
await assert.rejects(
  () => resolve("medical-manager", {}, repository(tree, { "Medical Manager": { viewTeamData: false } })),
  (error: OrganizationalHierarchyError) => error.code === "HIERARCHY_PERMISSION_DENIED",
);

const a = u("a", "General Manager", "b");
const b = u("b", "Country Manager", "a");
let cycleReads = 0;
const cycleRepo = repository([a, b]);
const cycle = await resolveOrganizationalScope("a", { depth: "descendants" }, {
  ...cycleRepo,
  async getDirectReports(managerUid) { cycleReads += 1; return [a, b].filter((record) => record.managerId === managerUid); },
});
assert.deepEqual(cycle.descendantUids, ["b"]);
assert.equal(cycleReads, 2);

let duplicateReads = 0;
const duplicate = await resolveOrganizationalScope("medical-manager", { depth: "descendants" }, {
  ...repository(),
  async getDirectReports(managerUid) {
    duplicateReads += 1;
    const reports = tree.filter((record) => record.managerId === managerUid);
    return [...reports, ...reports];
  },
});
assert.equal(new Set(duplicate.allHierarchyUids).size, duplicate.allHierarchyUids.length);
assert(duplicateReads > 0);

console.log("Backend organizational hierarchy authorization tests passed.");
