import { describe, expect, it } from "vitest";
import { postDeliveredInvoiceServer } from "./deliveredInvoicePostingService";
import type { DeliveredInvoicePostingRepository } from "./deliveredInvoicePostingRepository";

const ACTOR_UID = "delivery-uid";
const ORDER_ID = "order-1";
const LEDGER_ID = "LEDGER_INVOICE_order-1_INV-LY-SO-1";
const MARKET = {
  id: "MARKET-A", marketId: "MARKET-A", countryId: "COUNTRY-A", countryNameEn: "Country A", countryNameAr: "بلد أ",
  active: true, currencyCode: "AAA", currencySymbol: "A", symbolPosition: "AFTER", decimalPlaces: 2,
  numeralLocale: "en", timezone: "Etc/UTC", dateFormat: "YYYY-MM-DD", timeFormat: "24H", weekStartDay: 0,
  workingWeekdays: [0, 1, 2, 3, 4], normalWorkdayStart: "08:00", normalWorkdayEnd: "16:00",
  checkInOpensAt: "07:30", lateToleranceMinutes: 15, autoCheckoutAt: "18:00", maximumWorkdayMinutes: 600,
};

function fixture(overrides: Record<string, any> = {}) {
  const state: Record<string, any> = {
    actor: { id: ACTOR_UID, uid: ACTOR_UID, role: "Delivery Officer", active: true, loginAllowed: true, name: "Driver" },
    order: {
      id: ORDER_ID, displayNumber: "LY-SO-1", status: "DELIVERED", stage: "CLOSED",
      deliveryOfficerUid: ACTOR_UID, pharmacyId: "pharmacy-1", total: 200, marketId: "MARKET-A", currency: "AAA", deliveredAt: "2026-08-13T10:00:00.000Z",
    },
    existingLedger: null,
    profile: { id: "pharmacy-1", customerAccountNumber: "ACC-1", paymentTermCode: "CASH", paymentTermDays: 0, outstandingBalance: 10, totalInvoiced: 10, openInvoiceCount: 1 },
    pharmacy: { id: "pharmacy-1", name: "Test Pharmacy" },
    market: MARKET,
    ...overrides,
  };
  const writes: Array<{ ledger: Record<string, any>; profile: Record<string, any> }> = [];
  const repository: DeliveredInvoicePostingRepository = {
    async runTransaction(_actorUid, _orderId, operation) {
      return operation({
        ...state,
        ledgerId: LEDGER_ID,
        create(ledger, profile) {
          writes.push({ ledger, profile });
          state.existingLedger = ledger;
        },
      });
    },
  };
  return { repository, state, writes };
}

describe("DEF-WP76E-02 server-authoritative delivered invoice posting", () => {
  it("posts an authorized delivered invoice without changing the order", async () => {
    const f = fixture();
    const result = await postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository, now: () => "2026-08-13T12:00:00.000Z" });
    expect(result).toMatchObject({ success: true, posted: true, orderId: ORDER_ID, invoiceId: "INV-LY-SO-1", ledgerEntryId: LEDGER_ID });
    expect(f.writes[0].ledger).toMatchObject({ orderId: ORDER_ID, invoiceId: "INV-LY-SO-1", idempotencyKey: "DELIVERED_INVOICE_order-1_INV-LY-SO-1", debitAmount: 200 });
    expect(f.state.order).toMatchObject({ status: "DELIVERED", stage: "CLOSED" });
  });

  it("rejects an unassigned Delivery Officer", async () => {
    const f = fixture({ actor: { id: "other", role: "Delivery Officer", active: true, loginAllowed: true } });
    const result = await postDeliveredInvoiceServer("other", { orderId: ORDER_ID }, { repository: f.repository });
    expect(result).toMatchObject({ success: false, posted: false, code: "ACTOR_NOT_AUTHORIZED" });
    expect(f.writes).toHaveLength(0);
  });

  it("is idempotent when the deterministic ledger entry already exists", async () => {
    const f = fixture({ existingLedger: { id: LEDGER_ID, orderId: ORDER_ID, invoiceId: "INV-LY-SO-1" } });
    const result = await postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository });
    expect(result).toMatchObject({ success: true, posted: false, code: "ALREADY_POSTED", ledgerEntryId: LEDGER_ID });
    expect(f.writes).toHaveLength(0);
  });

  it("rejects posting before the canonical Delivered/Closed terminal pair", async () => {
    const f = fixture({ order: { id: ORDER_ID, status: "OUT_FOR_DELIVERY", stage: "DELIVERY", deliveryOfficerUid: ACTOR_UID } });
    const result = await postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository });
    expect(result).toMatchObject({ success: false, posted: false, code: "ORDER_NOT_DELIVERED" });
  });

  it("preserves canonical invoice identity and increments the existing profile once", async () => {
    const f = fixture();
    await postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository });
    expect(f.writes[0].ledger).toMatchObject({ id: LEDGER_ID, sourceType: "DELIVERED_ORDER", sourceId: ORDER_ID, invoiceNumber: "INV-LY-SO-1" });
    expect(f.writes[0].profile).toMatchObject({ outstandingBalance: 210, totalInvoiced: 210, openInvoiceCount: 2 });
  });

  it("fails closed when legacy records contain no resolvable financial identity", async () => {
    const f = fixture({
      order: { id: ORDER_ID, displayNumber: "SO-1", status: "DELIVERED", stage: "CLOSED", deliveryOfficerUid: ACTOR_UID, pharmacyId: "pharmacy-1", total: 200 },
      profile: { id: "pharmacy-1", customerAccountNumber: "ACC-1" },
      pharmacy: { id: "pharmacy-1", name: "Unknown Market Pharmacy" },
    });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository }))
      .resolves.toMatchObject({ success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" });
    expect(f.writes).toHaveLength(0);
  });

  it("persists the explicit market and currency for new-format records", async () => {
    const f = fixture({
      order: { id: ORDER_ID, displayNumber: "JO-SO-1", status: "DELIVERED", stage: "CLOSED", deliveryOfficerUid: ACTOR_UID, pharmacyId: "pharmacy-1", total: 200, marketId: "MARKET-B", currencyCode: "BBB" },
      profile: null,
      pharmacy: { id: "pharmacy-1", name: "Arbitrary Pharmacy", marketId: "MARKET-B", countryId: "COUNTRY-B" },
      market: { ...MARKET, id: "MARKET-B", marketId: "MARKET-B", countryId: "COUNTRY-B", currencyCode: "BBB" },
    });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository }))
      .resolves.toMatchObject({ success: true, posted: true });
    expect(f.writes[0].ledger).toMatchObject({ marketId: "MARKET-B", countryId: "COUNTRY-B", currency: "BBB", currencyCode: "BBB" });
    expect(f.writes[0].profile).toMatchObject({ marketId: "MARKET-B", countryId: "COUNTRY-B", currency: "BBB", currencyCode: "BBB" });
  });

  it("rejects a currency mismatch against the persisted market", async () => {
    const f = fixture({ order: { ...fixture().state.order, currencyCode: "BBB" } });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository }))
      .resolves.toMatchObject({ success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" });
  });

  it("rejects an inactive persisted market without falling back to bundled defaults", async () => {
    const f = fixture({ market: { ...MARKET, active: false } });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: f.repository }))
      .resolves.toMatchObject({ success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" });
  });

  it("rejects a missing or malformed persisted market", async () => {
    const missing = fixture({ market: null });
    const malformed = fixture({ market: { ...MARKET, currencyCode: "" } });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: missing.repository }))
      .resolves.toMatchObject({ success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" });
    await expect(postDeliveredInvoiceServer(ACTOR_UID, { orderId: ORDER_ID }, { repository: malformed.repository }))
      .resolves.toMatchObject({ success: false, posted: false, code: "FINANCIAL_MARKET_CURRENCY_REQUIRED" });
  });
});
