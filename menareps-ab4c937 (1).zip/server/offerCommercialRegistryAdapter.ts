import { deterministicCompanyMarketId } from "../src/lib/commercialRegistry";
import type { CanonicalOfferCommercialContext, CanonicalOfferDefinition } from "../src/features/offers/types";
import type { CommercialMarketRegistryRepository } from "./commercialMarketRegistryRepository";
import {
  classifyMarketResolution,
  resolveCommercialMarketRegistry,
  type CanonicalCommercialScope,
  type CommercialRegistryResolution,
} from "./commercialMarketRegistryResolver";

export type OfferCommercialRegistryErrorCode =
  | "OFFER_COMMERCIAL_SCOPE_INVALID"
  | "OFFER_COMMERCIAL_CONFIGURATION_INVALID"
  | "OFFER_COMMERCIAL_MARKET_REQUIRED"
  | "OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED"
  | "OFFER_COMMERCIAL_SELECTION_MISMATCH"
  | "OFFER_COMMERCIAL_PRODUCT_UNAVAILABLE"
  | "OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED";

export class OfferCommercialRegistryError extends Error {
  constructor(public readonly code: OfferCommercialRegistryErrorCode, public readonly status: number) {
    super(code);
    this.name = "OfferCommercialRegistryError";
  }
}

export interface OfferCommercialActorScope {
  global: boolean;
  companyIds: readonly string[];
  countryIds: readonly string[];
  marketIds: readonly string[];
  productIds: readonly string[];
}

export interface OfferCommercialRegistryDependencies {
  repository: CommercialMarketRegistryRepository;
  resolver: (scope: CanonicalCommercialScope, repository: CommercialMarketRegistryRepository) => Promise<CommercialRegistryResolution>;
  clock: () => string;
}

export interface OfferCommercialOptions {
  state: "ZERO" | "ONE" | "MULTIPLE";
  relationships: Array<{
    companyMarketId: string;
    companyId: string;
    marketId: string;
    countryId: string;
    companyName: string;
    marketName: string;
    countryName: string;
    currencyCode: string;
    products: Array<{ productId: string; name: string }>;
  }>;
}

export function createOfferCommercialRegistryDependencies(
  repository: CommercialMarketRegistryRepository,
  clock: () => string = () => new Date().toISOString(),
): OfferCommercialRegistryDependencies {
  return { repository, resolver: resolveCommercialMarketRegistry, clock };
}

type CommercialDefinition = Pick<CanonicalOfferDefinition, "eligibility" | "productScope" | "benefit">;

function scopeFor(actor: OfferCommercialActorScope, effectiveAt: string): CanonicalCommercialScope {
  return {
    global: actor.global,
    authorizedCompanyIds: actor.global ? [] : [...actor.companyIds],
    authorizedCountryIds: actor.global ? [] : [...actor.countryIds],
    authorizedProductIds: actor.global ? [] : [...actor.productIds],
    productScopeRequired: !actor.global && actor.productIds.length > 0,
    effectiveAt,
  };
}

function failResolution(result: Exclude<CommercialRegistryResolution, { ok: true }>): never {
  if (result.code === "COMMERCIAL_SCOPE_INVALID") throw new OfferCommercialRegistryError("OFFER_COMMERCIAL_SCOPE_INVALID", 403);
  throw new OfferCommercialRegistryError("OFFER_COMMERCIAL_CONFIGURATION_INVALID", 409);
}

async function authorizedRegistry(actor: OfferCommercialActorScope, dependencies: OfferCommercialRegistryDependencies, effectiveAt: string) {
  const result = await dependencies.resolver(scopeFor(actor, effectiveAt), dependencies.repository);
  if (result.ok === false) failResolution(result);
  const markets = actor.global || actor.marketIds.length === 0
    ? result.value.markets
    : result.value.markets.filter(value => actor.marketIds.includes(value.marketId));
  return { registry: result.value, markets };
}

export async function resolveOfferCommercialOptions(
  actor: OfferCommercialActorScope,
  dependencies: OfferCommercialRegistryDependencies,
  effectiveAt = dependencies.clock(),
): Promise<OfferCommercialOptions> {
  const { registry, markets } = await authorizedRegistry(actor, dependencies, effectiveAt);
  return {
    state: classifyMarketResolution(markets),
    relationships: markets.map(market => ({
      companyMarketId: deterministicCompanyMarketId(market.companyId, market.marketId),
      companyId: market.companyId,
      marketId: market.marketId,
      countryId: market.countryId,
      companyName: registry.companies.find(value => value.companyId === market.companyId)!.name,
      marketName: market.nameEn,
      countryName: registry.countries.find(value => value.countryId === market.countryId)!.nameEn,
      currencyCode: market.currencyCode,
      products: registry.products
        .filter(value => value.companyId === market.companyId && value.marketId === market.marketId)
        .map(value => ({ productId: value.productId, name: value.name })),
    })),
  };
}

export async function resolveOfferCommercialContext(
  actor: OfferCommercialActorScope,
  definition: CommercialDefinition,
  dependencies: OfferCommercialRegistryDependencies,
  effectiveAt = dependencies.clock(),
): Promise<{ eligibility: CanonicalOfferDefinition["eligibility"]; commercialContext: CanonicalOfferCommercialContext }> {
  const { registry, markets: authorizedMarkets } = await authorizedRegistry(actor, dependencies, effectiveAt);
  const state = classifyMarketResolution(authorizedMarkets);
  if (state === "ZERO") throw new OfferCommercialRegistryError("OFFER_COMMERCIAL_MARKET_REQUIRED", 409);

  const submitted = definition.eligibility as CanonicalOfferDefinition["eligibility"] & { companyId?: string; marketId?: string; countryId?: string };
  const selected = submitted.companyMarketId
    ? authorizedMarkets.filter(value => deterministicCompanyMarketId(value.companyId, value.marketId) === submitted.companyMarketId)
    : submitted.companyId && submitted.marketId
      ? authorizedMarkets.filter(value => value.companyId === submitted.companyId && value.marketId === submitted.marketId)
      : [];
  if (selected.length !== 1) {
    throw new OfferCommercialRegistryError(state === "MULTIPLE" ? "OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED" : "OFFER_COMMERCIAL_SELECTION_MISMATCH", 422);
  }
  const market = selected[0];
  const companyMarketId = deterministicCompanyMarketId(market.companyId, market.marketId);
  if ((submitted.companyMarketId && submitted.companyMarketId !== companyMarketId)
    || (submitted.companyId && submitted.companyId !== market.companyId)
    || (submitted.marketId && submitted.marketId !== market.marketId)
    || (submitted.countryId && submitted.countryId !== market.countryId)) {
    throw new OfferCommercialRegistryError("OFFER_COMMERCIAL_SELECTION_MISMATCH", 422);
  }

  const triggerIds = definition.productScope.mode === "SELECTED_PRODUCTS" ? definition.productScope.productIds : [];
  const rewardId = "reward" in definition.benefit && definition.benefit.reward.mode === "SELECTED_PRODUCT"
    ? definition.benefit.reward.rewardProductId : undefined;
  const requestedProductIds = [...new Set([...triggerIds, ...(rewardId ? [rewardId] : [])])];
  const products = requestedProductIds.map(productId => registry.products.find(value => value.productId === productId && value.companyId === market.companyId && value.marketId === market.marketId));
  if (products.some(value => !value)) {
    const authorizedElsewhere = requestedProductIds.some(productId => registry.products.some(value => value.productId === productId));
    throw new OfferCommercialRegistryError(authorizedElsewhere ? "OFFER_COMMERCIAL_PRODUCT_UNAVAILABLE" : "OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED", 422);
  }
  const eligibility = { ...definition.eligibility, companyMarketId, companyId: market.companyId, marketId: market.marketId, countryId: market.countryId } as CanonicalOfferDefinition["eligibility"];
  return {
    eligibility,
    commercialContext: {
      companyMarketId, companyId: market.companyId, marketId: market.marketId, countryId: market.countryId,
      currencyCode: market.currencyCode,
      products: products.map(value => ({ productId: value!.productId, unitPrice: value!.unitPrice, currencyCode: value!.currencyCode })),
      resolvedAt: effectiveAt,
    },
  };
}
