import { describe, expect, it } from "vitest";
import { CANONICAL_OFFER_TYPES, type CanonicalOfferDefinition } from "../src/features/offers/types";
import { defaultOfferCapabilities, resolveOfferCapabilities } from "./offerAuthorization";
import {
  createOfferDraft as createOfferDraftService, listOffers, mutateOffer as mutateOfferService, OfferAdministrationError, readOffer, validateOfferActorProfile,
  type OfferAdministrationActor, type OfferAdministrationRepository, type OfferDraftDefinitionInput,
} from "./offerAdministrationService";
import type { OfferCommercialRegistryDependencies } from "./offerCommercialRegistryAdapter";

const NOW = "2026-09-05T12:00:00.000Z";
const actor = (role = "Admin", overrides: Partial<OfferAdministrationActor> = {}): OfferAdministrationActor => ({
  uid: "ACTOR-1", role, permissions: null,
  scope: { global: role === "Admin" || role === "Super Admin", companyIds: ["COMPANY-1"], countryIds: ["COUNTRY-1"], marketIds: ["MARKET-1"], areaIds: ["AREA-1"], productIds: ["PRODUCT-1", "PRODUCT-2"] },
  ...overrides,
});

const percentageBenefit = { kind: "PRODUCT_PERCENTAGE" as const, percentage: 10, base: "ELIGIBLE_PAID_PRODUCT_LINES" as const };
const draft = (overrides: Partial<OfferDraftDefinitionInput> = {}): OfferDraftDefinitionInput => ({
  code: "OFF-TEST", name: "Test Offer", type: "PRODUCT_PERCENTAGE",
  productScope: { mode: "ALL_PRODUCTS", productIds: [] }, benefit: percentageBenefit,
  eligibility: {
    companyId: "COMPANY-1", marketId: "MARKET-1", countryId: "COUNTRY-1", startAt: "2026-09-01T00:00:00.000Z", endAt: "2026-09-30T23:59:59.999Z",
    productVerificationPolicy: "REQUIRE_ACTIVE_COMMERCIAL_PRODUCTS_AT_OPERATIONAL_USE", marketTimePolicy: "EVALUATE_IN_AUTHORITATIVE_MARKET_TIMEZONE",
  },
  stackingPolicy: { mode: "NO_STACKING", priority: 0, maximumProductOrQuantityOffersPerPaidLine: 1, maximumInvoicePercentageOffersPerInvoice: 1 },
  ...overrides,
});

class MemoryRepository implements OfferAdministrationRepository {
  private queue: Promise<void> = Promise.resolve();
  documents = new Map<string, Record<string, unknown>>();
  products = new Map<string, Record<string, unknown>>([["PRODUCT-1", { active: true }], ["PRODUCT-2", { active: true }]]);
  markets = new Map<string, Record<string, unknown>>([["MARKET-1", { active: true, countryId: "COUNTRY-1" }]]);
  async list() { return [...this.documents].map(([id, data]) => ({ id, data })); }
  async get(id: string) { return this.documents.get(id) || null; }
  async create(id: string, data: CanonicalOfferDefinition) { if (this.documents.has(id)) throw new Error("exists"); this.documents.set(id, structuredClone(data) as unknown as Record<string, unknown>); }
  async transact(id: string, expectedRevision: number, mutate: (current: Record<string, unknown>) => CanonicalOfferDefinition | Promise<CanonicalOfferDefinition>) {
    let release!: () => void; const previous = this.queue; this.queue = new Promise<void>(resolve => { release = resolve; }); await previous;
    try { const current = this.documents.get(id); if (!current) throw new OfferAdministrationError("OFFER_NOT_FOUND", 404); if (current.schemaVersion === 1 && current.revision !== expectedRevision) throw new OfferAdministrationError("OFFER_STALE_REVISION", 409); const next = await mutate(structuredClone(current)); this.documents.set(id, structuredClone(next) as unknown as Record<string, unknown>); return next; }
    finally { release(); }
  }
  async getProduct(id: string) { return this.products.get(id) || null; }
  async getMarket(id: string) { return this.markets.get(id) || null; }
  async getGeographyPath(id: string) { return id === "AREA-1" ? { countryId: "COUNTRY-1", districtId: "DISTRICT-1", cityId: "CITY-1", areaId: "AREA-1", active: true } : null; }
}

const commercialDependencies = (): OfferCommercialRegistryDependencies => ({
  repository: {} as never,
  clock: () => NOW,
  resolver: async () => ({ ok: true, value: {
    state: "ONE", companies: [{ companyId: "COMPANY-1", name: "Synthetic Company" }],
    countries: [{ countryId: "COUNTRY-1", nameEn: "Synthetic Country", nameAr: "Synthetic Country Arabic" }],
    markets: [{ marketId: "MARKET-1", companyId: "COMPANY-1", countryId: "COUNTRY-1", nameEn: "Synthetic Country", nameAr: "Synthetic Country Arabic", currencyCode: "XAA", currencySymbol: "XAA", decimalPlaces: 2 }],
    products: ["PRODUCT-1", "PRODUCT-2"].map((productId, index) => ({ productId, name: `Synthetic ${productId}`, companyId: "COMPANY-1", marketId: "MARKET-1", unitPrice: 10 + index, currencyCode: "XAA" })),
    catalogConfigurations: [],
  } }),
});
const createOfferDraft = (user: OfferAdministrationActor, input: OfferDraftDefinitionInput, repository: OfferAdministrationRepository, options: { id?: string; now?: string } = {}) =>
  createOfferDraftService(user, input, repository, commercialDependencies(), options);
const mutateOffer = (user: OfferAdministrationActor, command: Parameters<typeof mutateOfferService>[1], repository: OfferAdministrationRepository, options: { now?: string } = {}) =>
  mutateOfferService(user, command, repository, commercialDependencies(), options);

const errorCode = async (work: () => Promise<unknown>) => { try { await work(); return "PASS"; } catch (error) { return (error as OfferAdministrationError).code; } };
const create = async (repository = new MemoryRepository(), input = draft(), user = actor()) => ({ repository, offer: await createOfferDraft(user, input, repository, { id: "OFFER-1", now: NOW }) });

describe("Offer Phase 2 authorization", () => {
  it("fails closed for unauthenticated, missing and inactive actors", () => {
    expect(() => validateOfferActorProfile("", {})).toThrowError(expect.objectContaining({ code: "OFFER_AUTHENTICATION_REQUIRED" }));
    expect(() => validateOfferActorProfile("UID", null)).toThrowError(expect.objectContaining({ code: "OFFER_ACTOR_NOT_FOUND" }));
    expect(() => validateOfferActorProfile("UID", { role: "Admin", active: false })).toThrowError(expect.objectContaining({ code: "OFFER_ACTOR_INACTIVE" }));
  });
  it("provides the approved creator and approver matrices", () => {
    for (const role of ["Super Admin", "Admin"]) expect(defaultOfferCapabilities(role)["offers.cancel"]).toBe(true);
    for (const role of ["Sales & Marketing Manager", "Sales Manager"]) { expect(defaultOfferCapabilities(role)["offers.create"]).toBe(true); expect(defaultOfferCapabilities(role)["offers.approve"]).toBe(false); }
    for (const role of ["Sales Representative", "Finance Officer", "Warehouse Manager", "Inventory Officer", "Order Operations Officer"]) expect(defaultOfferCapabilities(role)["offers.view"]).toBe(false);
    expect(defaultOfferCapabilities("Sales Representative")["offers.applyDuringVisit"]).toBe(true);
    expect(defaultOfferCapabilities("Finance Officer")["offers.applyDuringVisit"]).toBe(false);
  });
  it("allows all four creator roles to create Drafts", async () => {
    for (const role of ["Super Admin", "Admin", "Sales & Marketing Manager", "Sales Manager"]) {
      await expect(createOfferDraft(actor(role, { scope: { ...actor().scope, global: role === "Super Admin" || role === "Admin" } }), draft(), new MemoryRepository(), { id: `OFFER-${role}`, now: NOW })).resolves.toMatchObject({ lifecycleStatus: "DRAFT", revision: 1 });
    }
  });
  it("honors restriction-only capability overrides", () => {
    expect(resolveOfferCapabilities("Admin", { offerCapabilities: { "offers.create": false } } as any)["offers.create"]).toBe(false);
    expect(resolveOfferCapabilities("Finance Officer", { offerCapabilities: { "offers.view": true } } as any)["offers.view"]).toBe(false);
  });
  it("enforces a dynamic denial on direct mutations", async () => {
    const restricted = actor("Admin", { permissions: { offerCapabilities: { "offers.create": false } } as any });
    expect(await errorCode(() => createOfferDraft(restricted, draft(), new MemoryRepository()))).toBe("OFFER_PERMISSION_DENIED");
  });
  it("denies direct service calls without capability", async () => expect(await errorCode(() => createOfferDraft(actor("Sales Representative"), draft(), new MemoryRepository()))).toBe("OFFER_PERMISSION_DENIED"));
});

describe("Offer Phase 2 creation and references", () => {
  it("creates every supported type only as canonical Draft with server fields", async () => {
    const benefits: Record<string, any> = {
      PRODUCT_PERCENTAGE: percentageBenefit,
      INVOICE_PERCENTAGE: { kind: "INVOICE_PERCENTAGE", percentage: 5, base: "PAID_ELIGIBLE_SUBTOTAL_AFTER_PRODUCT_DISCOUNTS_BEFORE_TAX", excludesFreeLines: true, excludesProductsOutsideScope: true },
      BUY_X_GET_Y: { kind: "BUY_X_GET_Y", buyQuantity: 5, freeQuantity: 1, reward: { mode: "SAME_AS_TRIGGER" }, aggregationMode: "PER_PRODUCT", multiples: "REPEAT_COMPLETE_MULTIPLES", remainder: "NO_REWARD_BELOW_THRESHOLD" },
      TIER_BONUS: { kind: "TIER_BONUS", tiers: [{ buyQuantity: 5, freeQuantity: 1 }], reward: { mode: "SELECTED_PRODUCT", rewardProductId: "PRODUCT-2" }, aggregationMode: "PER_PRODUCT", applicationMode: "REPEATING_GREEDY_WITH_REMAINDER" },
    };
    for (const type of CANONICAL_OFFER_TYPES) {
      const result = await create(new MemoryRepository(), draft({ type, benefit: benefits[type] } as any));
      expect(result.offer).toMatchObject({ id: "OFFER-1", schemaVersion: 1, offerVersion: 1, revision: 1, lifecycleStatus: "DRAFT", createdBy: "ACTOR-1", updatedBy: "ACTOR-1" });
    }
  });
  it("accepts one and multiple canonical Selected Products", async () => {
    for (const productIds of [["PRODUCT-1"], ["PRODUCT-1", "PRODUCT-2"]]) expect((await create(new MemoryRepository(), draft({ productScope: { mode: "SELECTED_PRODUCTS", productIds } }))).offer.productScope.productIds).toEqual(productIds);
  });
  it("rejects empty selected, fixed, unknown, malformed reward and sixth tier definitions", async () => {
    const invalid = [
      draft({ productScope: { mode: "SELECTED_PRODUCTS", productIds: [] } }),
      draft({ type: "FIXED_DISCOUNT" as any }), draft({ type: "UNKNOWN" as any }),
      draft({ type: "BUY_X_GET_Y", benefit: { kind: "BUY_X_GET_Y", buyQuantity: 5, freeQuantity: 1, reward: { mode: "SELECTED_PRODUCT" }, aggregationMode: "PER_PRODUCT", multiples: "REPEAT_COMPLETE_MULTIPLES", remainder: "NO_REWARD_BELOW_THRESHOLD" } as any }),
      draft({ type: "TIER_BONUS", benefit: { kind: "TIER_BONUS", tiers: Array.from({ length: 6 }, (_, i) => ({ buyQuantity: i + 1, freeQuantity: 1 })), reward: { mode: "SAME_AS_TRIGGER" }, aggregationMode: "PER_PRODUCT", applicationMode: "REPEATING_GREEDY_WITH_REMAINDER" } }),
    ];
    for (const value of invalid) expect(await errorCode(() => createOfferDraft(actor(), value, new MemoryRepository()))).toBe("OFFER_INVALID_DEFINITION");
  });
  it("rejects a product absent from the canonical commercial resolution", async () => {
    expect(await errorCode(() => createOfferDraft(actor(), draft({ productScope: { mode: "SELECTED_PRODUCTS", productIds: ["BAD"] } }), new MemoryRepository()))).toBe("OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED");
  });
  it("enforces company, market, complete geography and product assignment scope", async () => {
    const scoped = actor("Sales Manager", { scope: { ...actor().scope, global: false } });
    expect(await errorCode(() => createOfferDraft(scoped, draft({ eligibility: { ...draft().eligibility, companyId: "OTHER" } }), new MemoryRepository()))).toBe("OFFER_COMMERCIAL_SELECTION_MISMATCH");
    expect(await errorCode(() => createOfferDraft(scoped, draft({ eligibility: { ...draft().eligibility, geographyPaths: [{ countryId: "COUNTRY-1", districtId: "WRONG", cityId: "CITY-1", areaId: "AREA-1" }] } }), new MemoryRepository()))).toBe("OFFER_SCOPE_DENIED");
  });
});

describe("Offer Phase 2 lifecycle and concurrency", () => {
  it.each(["UPDATE_DRAFT", "SUBMIT", "APPROVE", "ACTIVATE", "REACTIVATE"] as const)("revalidates commercial configuration before %s without rejected mutation", async action => {
    const repository = new MemoryRepository();
    const dependencies = commercialDependencies();
    let valid = true;
    const resolver = dependencies.resolver;
    dependencies.resolver = async (...args) => valid ? resolver(...args) : ({ ok: false, code: "COMMERCIAL_REGISTRY_INTEGRITY_ERROR", details: ["SYNTHETIC_CONFIGURATION_CHANGE"] });
    await createOfferDraftService(actor(), draft(), repository, dependencies, { id: "OFFER-1", now: NOW });
    const approver = actor("Admin", { uid: "ACTOR-2" });
    if (["APPROVE", "ACTIVATE", "REACTIVATE"].includes(action)) await mutateOfferService(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, dependencies, { now: NOW });
    if (["ACTIVATE", "REACTIVATE"].includes(action)) await mutateOfferService(approver, { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository, dependencies, { now: NOW });
    if (action === "REACTIVATE") {
      await mutateOfferService(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, dependencies, { now: NOW });
      await mutateOfferService(approver, { action: "PAUSE", offerId: "OFFER-1", expectedRevision: 4 }, repository, dependencies, { now: NOW });
    }
    const before = structuredClone(repository.documents.get("OFFER-1"));
    valid = false;
    const revision = Number((before as Record<string, unknown>).revision);
    const command = action === "UPDATE_DRAFT"
      ? { action, offerId: "OFFER-1", expectedRevision: revision, definition: draft({ name: "Rejected edit" }) } as const
      : { action, offerId: "OFFER-1", expectedRevision: revision } as const;
    const acting = action === "SUBMIT" || action === "UPDATE_DRAFT" ? actor() : approver;
    await expect(mutateOfferService(acting, command, repository, dependencies, { now: NOW })).rejects.toMatchObject({ code: "OFFER_COMMERCIAL_CONFIGURATION_INVALID" });
    expect(repository.documents.get("OFFER-1")).toEqual(before);
  });

  it("updates Draft transactionally and increments revision exactly once", async () => { const { repository } = await create(); const next = await mutateOffer(actor(), { action: "UPDATE_DRAFT", offerId: "OFFER-1", expectedRevision: 1, definition: draft({ name: "Changed" }) }, repository, { now: NOW }); expect(next).toMatchObject({ name: "Changed", revision: 2, createdBy: "ACTOR-1" }); });
  it("submits and returns to Draft", async () => { const { repository } = await create(); const submitted = await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW }); expect(submitted.lifecycleStatus).toBe("PENDING_APPROVAL"); const returned = await mutateOffer(actor("Admin", { uid: "ACTOR-2" }), { action: "RETURN_TO_DRAFT", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW }); expect(returned).toMatchObject({ lifecycleStatus: "DRAFT", revision: 3 }); });
  it("separates creator approval and activation", async () => { const { repository } = await create(); await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW }); expect(await errorCode(() => mutateOffer(actor(), { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository))).toBe("OFFER_MAKER_APPROVER_CONFLICT"); const approver = actor("Admin", { uid: "ACTOR-2" }); const approved = await mutateOffer(approver, { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW }); expect(approved.approvedBy).toBe("ACTOR-2"); expect(await errorCode(() => mutateOffer(actor(), { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, { now: NOW }))).toBe("OFFER_MAKER_APPROVER_CONFLICT"); const active = await mutateOffer(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, { now: NOW }); expect(active.lifecycleStatus).toBe("ACTIVE"); });
  it("prevents editor and submitter makers, including Super Admin, from approval", async () => {
    const { repository } = await create();
    await mutateOffer(actor("Sales Manager", { uid: "ACTOR-2", scope: { ...actor().scope, global: false } }), { action: "UPDATE_DRAFT", offerId: "OFFER-1", expectedRevision: 1, definition: draft({ name: "Edited" }) }, repository, { now: NOW });
    await mutateOffer(actor("Sales & Marketing Manager", { uid: "ACTOR-3", scope: { ...actor().scope, global: false } }), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW });
    for (const uid of ["ACTOR-2", "ACTOR-3"]) expect(await errorCode(() => mutateOffer(actor("Super Admin", { uid }), { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 3 }, repository))).toBe("OFFER_MAKER_APPROVER_CONFLICT");
  });
  it("requires approval before activation", async () => { const { repository } = await create(); await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW }); expect(await errorCode(() => mutateOffer(actor("Admin", { uid: "ACTOR-2" }), { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW }))).toBe("OFFER_INVALID_TRANSITION"); });
  it("pauses, reactivates and cancels with a reason", async () => { const { repository } = await create(); await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW }); const approver = actor("Admin", { uid: "ACTOR-2" }); await mutateOffer(approver, { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW }); await mutateOffer(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, { now: NOW }); await mutateOffer(approver, { action: "PAUSE", offerId: "OFFER-1", expectedRevision: 4 }, repository, { now: NOW }); await mutateOffer(approver, { action: "REACTIVATE", offerId: "OFFER-1", expectedRevision: 5 }, repository, { now: NOW }); expect(await errorCode(() => mutateOffer(approver, { action: "CANCEL", offerId: "OFFER-1", expectedRevision: 6, reason: " " }, repository))).toBe("OFFER_CANCELLATION_REASON_REQUIRED"); const cancelled = await mutateOffer(approver, { action: "CANCEL", offerId: "OFFER-1", expectedRevision: 6, reason: "Campaign withdrawn" }, repository, { now: NOW }); expect(cancelled).toMatchObject({ lifecycleStatus: "CANCELLED", cancellationReason: "Campaign withdrawn", revision: 7 }); });
  it("rejects stale revisions and preserves one authoritative winner", async () => { const { repository } = await create(); const first = mutateOffer(actor(), { action: "UPDATE_DRAFT", offerId: "OFFER-1", expectedRevision: 1, definition: draft({ name: "First" }) }, repository); const second = mutateOffer(actor(), { action: "UPDATE_DRAFT", offerId: "OFFER-1", expectedRevision: 1, definition: draft({ name: "Second" }) }, repository); const results = await Promise.allSettled([first, second]); expect(results.filter(result => result.status === "fulfilled")).toHaveLength(1); expect(results.filter(result => result.status === "rejected")).toHaveLength(1); });
  it("does not accept client-controlled server fields", async () => { const input = { ...draft(), lifecycleStatus: "ACTIVE", revision: 99, createdBy: "CLIENT", approvedBy: "CLIENT" } as any; const { offer } = await create(new MemoryRepository(), input); expect(offer).toMatchObject({ lifecycleStatus: "DRAFT", revision: 1, createdBy: "ACTOR-1" }); expect(offer.approvedBy).toBeUndefined(); });
  it("schedules future approval, activates when due, rejects active edits and protects terminal status", async () => {
    const { repository } = await create(); const approver = actor("Admin", { uid: "ACTOR-2" });
    await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW });
    await mutateOffer(approver, { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW });
    const scheduled = await mutateOffer(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, { now: "2026-08-01T00:00:00.000Z" });
    expect(scheduled).toMatchObject({ lifecycleStatus: "SCHEDULED", scheduledBy: "ACTOR-2", revision: 4 });
    await mutateOffer(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 4 }, repository, { now: NOW });
    expect(await errorCode(() => mutateOffer(actor(), { action: "UPDATE_DRAFT", offerId: "OFFER-1", expectedRevision: 5, definition: draft() }, repository))).toBe("OFFER_INVALID_TRANSITION");
    await mutateOffer(approver, { action: "CANCEL", offerId: "OFFER-1", expectedRevision: 5, reason: "End" }, repository, { now: NOW });
    expect(await errorCode(() => mutateOffer(approver, { action: "PAUSE", offerId: "OFFER-1", expectedRevision: 6 }, repository))).toBe("OFFER_INVALID_TRANSITION");
  });
  it("allows an approved Scheduled Offer to be cancelled before start", async () => {
    const { repository } = await create(); const approver = actor("Admin", { uid: "ACTOR-2" });
    await mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository, { now: NOW });
    await mutateOffer(approver, { action: "APPROVE", offerId: "OFFER-1", expectedRevision: 2 }, repository, { now: NOW });
    await mutateOffer(approver, { action: "ACTIVATE", offerId: "OFFER-1", expectedRevision: 3 }, repository, { now: "2026-08-01T00:00:00.000Z" });
    const cancelled = await mutateOffer(approver, { action: "CANCEL", offerId: "OFFER-1", expectedRevision: 4, reason: "Cancelled before launch" }, repository, { now: "2026-08-02T00:00:00.000Z" });
    expect(cancelled.lifecycleStatus).toBe("CANCELLED");
  });
});

describe("Offer Phase 2 legacy and read safety", () => {
  it("lists malformed legacy data defensively without coercing its type", async () => { const repository = new MemoryRepository(); repository.documents.set("LEGACY-1", { name: 12, type: "FIXED_DISCOUNT", companyId: "COMPANY-1", countryId: "COUNTRY-1" }); const records = await listOffers(actor(), repository); expect(records[0]).toMatchObject({ kind: "LEGACY", offer: { id: "LEGACY-1", legacyTypeLabel: "FIXED_DISCOUNT", status: "READ_ONLY_LEGACY" } }); });
  it("supports legacy detail and denies every mutation", async () => { const repository = new MemoryRepository(); repository.documents.set("LEGACY-1", { name: "Old", type: "UNKNOWN_OLD", companyId: "COMPANY-1", countryId: "COUNTRY-1" }); expect((await readOffer(actor(), "LEGACY-1", repository)).kind).toBe("LEGACY"); expect(await errorCode(() => mutateOffer(actor(), { action: "SUBMIT", offerId: "LEGACY-1", expectedRevision: 1 }, repository))).toBe("OFFER_LEGACY_READ_ONLY"); });
  it("fails unknown schema versions closed", async () => { const repository = new MemoryRepository(); repository.documents.set("FUTURE", { schemaVersion: 99, revision: 1, companyId: "COMPANY-1", countryId: "COUNTRY-1" }); expect(await errorCode(() => mutateOffer(actor(), { action: "SUBMIT", offerId: "FUTURE", expectedRevision: 1 }, repository))).toBe("OFFER_UNSUPPORTED_SCHEMA"); });
  it("classifies canonical Offers without complete maker history as legacy read-only", async () => { const { repository, offer } = await create(); const historical = structuredClone(offer) as any; delete historical.makerIds; delete historical.makerAudit; repository.documents.set("OFFER-1", historical); expect((await readOffer(actor(), "OFFER-1", repository)).kind).toBe("LEGACY"); expect(await errorCode(() => mutateOffer(actor(), { action: "SUBMIT", offerId: "OFFER-1", expectedRevision: 1 }, repository))).toBe("OFFER_MAKER_HISTORY_REQUIRED"); });
});
