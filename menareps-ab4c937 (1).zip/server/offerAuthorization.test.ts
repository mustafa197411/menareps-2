import { describe, expect, it } from "vitest";
import { OFFER_CAPABILITIES, OFFER_POLICY_ROLES } from "../src/features/offers/types";
import { defaultOfferCapabilities, resolveOfferCapabilities } from "./offerAuthorization";

describe("Offer restriction-only authorization", () => {
  it("derives the canonical role matrix from the existing registry", () => {
    for (const role of OFFER_POLICY_ROLES.approvers) expect(defaultOfferCapabilities(role)).toMatchObject({ "offers.view": true, "offers.create": true, "offers.approve": true, "offers.activate": true });
    for (const role of OFFER_POLICY_ROLES.creators.filter(role => !(OFFER_POLICY_ROLES.approvers as readonly string[]).includes(role))) expect(defaultOfferCapabilities(role)).toMatchObject({ "offers.view": true, "offers.create": true, "offers.submit": true, "offers.approve": false, "offers.activate": false });
    for (const role of OFFER_POLICY_ROLES.visitUsers) expect(defaultOfferCapabilities(role)).toMatchObject({ "offers.view": false, "offers.create": false, "offers.applyDuringVisit": true });
  });

  it("allows false to restrict but never allows true to extend a baseline", () => {
    expect(resolveOfferCapabilities("Admin", { offerCapabilities: { "offers.create": false } } as never)["offers.create"]).toBe(false);
    expect(resolveOfferCapabilities("Sales Manager", { offerCapabilities: { "offers.approve": true } } as never)["offers.approve"]).toBe(false);
    expect(resolveOfferCapabilities("Sales Representative", { offerCapabilities: { "offers.view": true } } as never)["offers.view"]).toBe(false);
    expect(resolveOfferCapabilities("Finance Officer", { offerCapabilities: Object.fromEntries(OFFER_CAPABILITIES.map(capability => [capability, true])) } as never)["offers.create"]).toBe(false);
  });
});
