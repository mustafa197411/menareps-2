import { describe, expect, it } from "vitest";
import type { MarketBusinessSettings } from "../src/lib/marketSettings";
import {
  COMMERCIAL_REGISTRY_SCHEMA_VERSION,
  deterministicCompanyMarketId,
  deterministicProductMarketCatalogId,
  type CompanyMarketAssignment,
  type ProductMarketCatalogEntry,
} from "../src/lib/commercialRegistry";
import type { CommercialMarketRegistryRepository, CommercialRegistryReadRequest } from "./commercialMarketRegistryRepository";
import { resolveCommercialMarketRegistry } from "./commercialMarketRegistryResolver";
import { OfferCommercialRegistryError, resolveOfferCommercialContext, resolveOfferCommercialOptions, type OfferCommercialActorScope, type OfferCommercialRegistryDependencies } from "./offerCommercialRegistryAdapter";

const NOW = "2032-04-15T10:00:00.000Z";
const AUDIT = { createdAt: "2031-01-01T00:00:00.000Z", createdBy: "SYNTHETIC_ACTOR_A", updatedAt: "2031-02-01T00:00:00.000Z", updatedBy: "SYNTHETIC_ACTOR_B" };
const company = (companyId: string, active = true) => ({ schemaVersion: COMMERCIAL_REGISTRY_SCHEMA_VERSION, companyId, name: `Synthetic ${companyId}`, active, ...AUDIT });
const country = (countryId: string, active = true) => ({ countryId, active, ...AUDIT });
const product = (productId: string, active = true) => ({ productId, name: `Synthetic ${productId}`, active, ...AUDIT });
const market = (marketId: string, countryId: string, currencyCode: string, active = true): MarketBusinessSettings => ({
  marketId, countryId, countryNameEn: `Synthetic ${countryId}`, countryNameAr: `Synthetic Arabic ${countryId}`, active,
  currencyCode, currencySymbol: currencyCode, symbolPosition: "AFTER", decimalPlaces: 2, numeralLocale: "en-US", timezone: "UTC",
  dateFormat: "YYYY-MM-DD", timeFormat: "24H", weekStartDay: 1, workingWeekdays: [1, 2, 3, 4, 5], normalWorkdayStart: "08:00",
  normalWorkdayEnd: "17:00", checkInOpensAt: "07:30", lateToleranceMinutes: 15, autoCheckoutAt: "19:00", maximumWorkdayMinutes: 540,
});
const relationship = (companyId: string, marketId: string, overrides: Partial<CompanyMarketAssignment> = {}): CompanyMarketAssignment => ({
  schemaVersion: COMMERCIAL_REGISTRY_SCHEMA_VERSION, companyMarketId: deterministicCompanyMarketId(companyId, marketId), companyId, marketId,
  active: true, effectiveFrom: "2032-01-01T00:00:00.000Z", ...AUDIT, ...overrides,
});
const catalog = (companyId: string, marketId: string, productId: string, unitPrice: number, overrides: Partial<ProductMarketCatalogEntry> = {}): ProductMarketCatalogEntry => ({
  schemaVersion: COMMERCIAL_REGISTRY_SCHEMA_VERSION,
  catalogEntryId: deterministicProductMarketCatalogId(companyId, marketId, productId, "2032-01-01T00:00:00.000Z"),
  companyMarketId: deterministicCompanyMarketId(companyId, marketId), companyId, marketId, productId, active: true, saleable: true,
  unitPrice, effectiveFrom: "2032-01-01T00:00:00.000Z", ...AUDIT, ...overrides,
});

type Data = { companies: unknown[]; countries: unknown[]; markets: unknown[]; relationships: unknown[]; catalog: unknown[]; products: unknown[] };
const data = (): Data => ({
  companies: [company("SYNTH_COMPANY_A"), company("SYNTH_COMPANY_B")],
  countries: [country("SYNTH_COUNTRY_A"), country("SYNTH_COUNTRY_B")],
  markets: [market("SYNTH_MARKET_A", "SYNTH_COUNTRY_A", "XAA"), market("SYNTH_MARKET_B", "SYNTH_COUNTRY_B", "XBB")],
  relationships: [relationship("SYNTH_COMPANY_A", "SYNTH_MARKET_A"), relationship("SYNTH_COMPANY_B", "SYNTH_MARKET_B")],
  catalog: [catalog("SYNTH_COMPANY_A", "SYNTH_MARKET_A", "SYNTH_PRODUCT_A", 17), catalog("SYNTH_COMPANY_B", "SYNTH_MARKET_B", "SYNTH_PRODUCT_B", 29)],
  products: [product("SYNTH_PRODUCT_A"), product("SYNTH_PRODUCT_B")],
});
const repository = (source: Data): CommercialMarketRegistryRepository => {
  const read = (values: unknown[], idField: string, filterField = idField) => async (request: CommercialRegistryReadRequest) => ({
    records: request.ids ? values.filter(value => request.ids!.includes((value as Record<string, string>)[filterField])) : values,
  });
  return {
    readCompanies: read(source.companies, "companyId"), readCountries: read(source.countries, "countryId"), readMarkets: read(source.markets, "marketId"),
    readCompanyMarkets: read(source.relationships, "companyMarketId", "companyId"), readProductMarketCatalog: read(source.catalog, "catalogEntryId", "companyMarketId"), readProducts: read(source.products, "productId"),
  };
};
const dependencies = (source: Data): OfferCommercialRegistryDependencies => ({ repository: repository(source), resolver: resolveCommercialMarketRegistry, clock: () => NOW });
const globalActor = (): OfferCommercialActorScope => ({ global: true, companyIds: [], countryIds: [], marketIds: [], productIds: [] });
const scopedActor = (overrides: Partial<OfferCommercialActorScope> = {}): OfferCommercialActorScope => ({ global: false, companyIds: ["SYNTH_COMPANY_A"], countryIds: ["SYNTH_COUNTRY_A"], marketIds: [], productIds: ["SYNTH_PRODUCT_A"], ...overrides });
const definition = (eligibility: Record<string, unknown> = { companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_MARKET_A", countryId: "SYNTH_COUNTRY_A" }, productIds = ["SYNTH_PRODUCT_A"]): any => ({
  eligibility: { ...eligibility, startAt: "2032-01-01T00:00:00.000Z", endAt: "2032-12-31T23:59:59.999Z", productVerificationPolicy: "REQUIRE_ACTIVE_COMMERCIAL_PRODUCTS_AT_OPERATIONAL_USE", marketTimePolicy: "EVALUATE_IN_AUTHORITATIVE_MARKET_TIMEZONE" },
  productScope: { mode: "SELECTED_PRODUCTS", productIds }, benefit: { kind: "PRODUCT_PERCENTAGE", percentage: 10, base: "ELIGIBLE_PAID_PRODUCT_LINES" },
});
const code = async (work: () => Promise<unknown>) => { try { await work(); return "PASS"; } catch (error) { return (error as OfferCommercialRegistryError).code; } };

describe("Offer canonical commercial registry adapter", () => {
  it("returns sanitized ZERO, ONE, and MULTIPLE UI option states without catalog prices", async () => {
    const multiple = await resolveOfferCommercialOptions(globalActor(), dependencies(data()));
    expect(multiple.state).toBe("MULTIPLE");
    expect(JSON.stringify(multiple)).not.toContain("unitPrice");
    const one = await resolveOfferCommercialOptions(scopedActor(), dependencies(data()));
    expect(one).toMatchObject({ state: "ONE", relationships: [{ companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_MARKET_A", countryId: "SYNTH_COUNTRY_A", currencyCode: "XAA", products: [{ productId: "SYNTH_PRODUCT_A" }] }] });
    const empty = data(); empty.relationships = []; empty.catalog = [];
    expect(await resolveOfferCommercialOptions(globalActor(), dependencies(empty))).toEqual({ state: "ZERO", relationships: [] });
  });
  it("derives relationship, country, currency, and prices for scoped actors", async () => {
    const result = await resolveOfferCommercialContext(scopedActor(), definition(), dependencies(data()));
    expect(result.eligibility).toMatchObject({ companyMarketId: deterministicCompanyMarketId("SYNTH_COMPANY_A", "SYNTH_MARKET_A"), companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_MARKET_A", countryId: "SYNTH_COUNTRY_A" });
    expect(result.commercialContext).toMatchObject({ currencyCode: "XAA", products: [{ productId: "SYNTH_PRODUCT_A", unitPrice: 17, currencyCode: "XAA" }] });
  });

  it("supports canonical relationship ID and requires selection for global multiple relationships", async () => {
    const source = data();
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition({}, []), dependencies(source)))).toBe("OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED");
    await expect(resolveOfferCommercialContext(globalActor(), definition({ companyMarketId: deterministicCompanyMarketId("SYNTH_COMPANY_B", "SYNTH_MARKET_B") }, ["SYNTH_PRODUCT_B"]), dependencies(source))).resolves.toMatchObject({ commercialContext: { companyId: "SYNTH_COMPANY_B", marketId: "SYNTH_MARKET_B", countryId: "SYNTH_COUNTRY_B", currencyCode: "XBB" } });
  });

  it("fails closed for two companies sharing one market unless the relationship is explicit", async () => {
    const source = data();
    source.markets = [market("SYNTH_MARKET_SHARED", "SYNTH_COUNTRY_A", "XAA")];
    source.relationships = [relationship("SYNTH_COMPANY_A", "SYNTH_MARKET_SHARED"), relationship("SYNTH_COMPANY_B", "SYNTH_MARKET_SHARED")];
    source.catalog = [];
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition({ marketId: "SYNTH_MARKET_SHARED" }, []), dependencies(source)))).toBe("OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED");
  });

  it.each([
    [{ companyId: "SYNTH_COMPANY_FORGED", marketId: "SYNTH_MARKET_A" }, "OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED"],
    [{ companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_MARKET_FORGED" }, "OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED"],
    [{ companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_MARKET_A", countryId: "SYNTH_COUNTRY_FORGED" }, "OFFER_COMMERCIAL_SELECTION_MISMATCH"],
    [{ companyMarketId: "SYNTH_RELATIONSHIP_FORGED" }, "OFFER_COMMERCIAL_MARKET_SELECTION_REQUIRED"],
  ])("rejects forged commercial selection %j", async (selection, expected) => {
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition(selection), dependencies(data())))).toBe(expected);
  });

  it("rejects zero, inactive, expired, and malformed commercial configuration", async () => {
    const zero = data(); zero.relationships = []; zero.catalog = [];
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition(), dependencies(zero)))).toBe("OFFER_COMMERCIAL_MARKET_REQUIRED");
    const inactive = data(); inactive.relationships = inactive.relationships.map(value => ({ ...(value as object), active: false }));
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition(), dependencies(inactive)))).toBe("OFFER_COMMERCIAL_CONFIGURATION_INVALID");
    const expired = data(); expired.relationships = expired.relationships.map(value => ({ ...(value as object), effectiveTo: "2032-04-14T23:59:59.999Z" }));
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition(), dependencies(expired)))).toBe("OFFER_COMMERCIAL_CONFIGURATION_INVALID");
    const malformed = data(); malformed.markets = [{ ...(malformed.markets[0] as object), currencyCode: "bad" }]; malformed.relationships = [malformed.relationships[0]]; malformed.catalog = [malformed.catalog[0]];
    expect(await code(() => resolveOfferCommercialContext(globalActor(), definition(), dependencies(malformed)))).toBe("OFFER_COMMERCIAL_CONFIGURATION_INVALID");
  });

  it("rejects cross-market, inactive, expired, and actor-unauthorized products", async () => {
    expect(await code(() => resolveOfferCommercialContext(scopedActor(), definition(undefined, ["SYNTH_PRODUCT_B"]), dependencies(data())))).toBe("OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED");
    const inactive = data(); inactive.catalog[0] = { ...(inactive.catalog[0] as object), active: false };
    expect(await code(() => resolveOfferCommercialContext(scopedActor(), definition(), dependencies(inactive)))).toBe("OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED");
    const expired = data(); expired.catalog[0] = { ...(expired.catalog[0] as object), effectiveTo: "2032-04-14T23:59:59.999Z" };
    expect(await code(() => resolveOfferCommercialContext(scopedActor(), definition(), dependencies(expired)))).toBe("OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED");
    expect(await code(() => resolveOfferCommercialContext(scopedActor({ productIds: ["SYNTH_PRODUCT_B"] }), definition(), dependencies(data())))).toBe("OFFER_COMMERCIAL_PRODUCT_UNAUTHORIZED");
  });

  it("never substitutes a country identifier for a market identifier", async () => {
    expect(await code(() => resolveOfferCommercialContext(scopedActor(), definition({ companyId: "SYNTH_COMPANY_A", marketId: "SYNTH_COUNTRY_A" }), dependencies(data())))).toBe("OFFER_COMMERCIAL_SELECTION_MISMATCH");
  });
});
