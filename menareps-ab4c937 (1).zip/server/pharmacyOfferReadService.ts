import type { Firestore } from "firebase-admin/firestore";
import { getFirebaseAdminServices } from "./firebaseAdmin";
import { createFirestoreOperationalScopeRepository, resolveOperationalScopeForActor, type OperationalScopeRepository } from "./operationalScopeRepository";
import { validateOfferActorProfile } from "./offerAdministrationService";
import { hasOfferCapability } from "./offerAuthorization";
import { validateCanonicalOfferDefinition } from "../src/features/offers/offerValidation";
import type { CanonicalOfferDefinition } from "../src/features/offers/types";
import type { Permissions } from "../src/types";
import { calculateOffersForServer } from "../src/features/offers/offerCalculation";
import { readProductAvailableToPromise } from "./pharmacyProductAvailabilityService";

export type PharmacyOfferReadCode = "OFFER_AUTHENTICATION_REQUIRED" | "OFFER_ACTOR_NOT_FOUND" | "OFFER_ACTOR_INACTIVE" | "OFFER_PERMISSION_DENIED" | "OFFER_PHARMACY_NOT_FOUND" | "OFFER_PHARMACY_INACTIVE" | "OFFER_SCOPE_DENIED" | "OFFER_PRODUCT_NOT_FOUND" | "OFFER_PRODUCT_INACTIVE" | "OFFER_CONFIGURATION_UNAVAILABLE";
export interface PharmacyOfferReadRequest { pharmacyId: string; productIds: string[]; paidLines?: Array<{ lineId: string; productId: string; quantity: number }>; selectedOfferIds?: string[] }
export interface PharmacyOfferReadRepository {
  getUser(id: string): Promise<Record<string, unknown> | null>;
  getPermissions(role: string): Promise<Permissions | null>;
  getPharmacy(id: string): Promise<Record<string, unknown> | null>;
  getProduct(id: string): Promise<Record<string, unknown> | null>;
  queryActive(): Promise<Array<{ id: string; data: Record<string, unknown> }>>;
}
const text = (value: unknown) => typeof value === "string" ? value.trim() : "";
const active = (value: Record<string, unknown>) => value.active !== false && value.isActive !== false && value.status !== "Inactive" && value.status !== "Archived";
const commercial = (value: Record<string, unknown>) => active(value) && value.isSample !== true && value.isSampleSku !== true && !/sample/i.test(text(value.productType));
const strings = (value: unknown) => Array.isArray(value) ? Array.from(new Set(value.map(text).filter(Boolean))).sort() : [];

export function parsePharmacyOfferReadRequest(value: unknown): PharmacyOfferReadRequest | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const row = value as Record<string, unknown>, pharmacyId = text(row.pharmacyId), productIds = strings(row.productIds);
  if (!pharmacyId || productIds.length === 0 || Object.keys(row).some(key => !["pharmacyId", "productIds", "paidLines", "selectedOfferIds"].includes(key))) return null;
  const paidLines = row.paidLines === undefined ? undefined : Array.isArray(row.paidLines) ? row.paidLines.map((line, index) => {
    const item = line as Record<string, unknown>, lineId = text(item?.lineId), productId = text(item?.productId), quantity = Number(item?.quantity);
    if (!line || typeof line !== "object" || Array.isArray(line) || Object.keys(item).some(key => !["lineId", "productId", "quantity"].includes(key)) || !lineId || !productIds.includes(productId) || !Number.isSafeInteger(quantity) || quantity <= 0) return null;
    return { lineId: lineId || `L${index}`, productId, quantity };
  }) : [null];
  if (paidLines?.some(line => !line)) return null;
  const selectedOfferIds = row.selectedOfferIds === undefined ? undefined : strings(row.selectedOfferIds);
  if (row.selectedOfferIds !== undefined && (!Array.isArray(row.selectedOfferIds) || selectedOfferIds!.length !== row.selectedOfferIds.length)) return null;
  return { pharmacyId, productIds, ...(paidLines ? { paidLines: paidLines as Array<{ lineId: string; productId: string; quantity: number }> } : {}), ...(selectedOfferIds ? { selectedOfferIds } : {}) };
}

export function physicalDemandIsAvailable(paidLines: readonly { productId: string; quantity: number }[], freeLines: readonly { rewardProductId: string; quantity: number }[], products: ReadonlyMap<string, Record<string, unknown>>): boolean {
  const demand = new Map<string, number>();
  for (const line of paidLines) demand.set(line.productId, (demand.get(line.productId) || 0) + line.quantity);
  for (const line of freeLines) demand.set(line.rewardProductId, (demand.get(line.rewardProductId) || 0) + line.quantity);
  for (const [productId, required] of demand) { const available = readProductAvailableToPromise(products.get(productId)); if (!Number.isSafeInteger(required) || available == null || available < required) return false; }
  return true;
}

export function createFirestorePharmacyOfferReadRepository(db: Firestore = getFirebaseAdminServices().db): PharmacyOfferReadRepository {
  const get = async (collection: string, id: string) => { const snap = await db.collection(collection).doc(id).get(); return snap.exists ? snap.data() || null : null; };
  return {
    getUser: id => get("users", id), getPermissions: async role => await get("rolePermissions", role) as Permissions | null,
    getPharmacy: id => get("pharmacies", id), getProduct: id => get("products", id),
    async queryActive() { const snap = await db.collection("offers").where("lifecycleStatus", "==", "ACTIVE").get(); return snap.docs.map(doc => ({ id: doc.id, data: doc.data() })); },
  };
}

function matchesOffer(offer: CanonicalOfferDefinition, request: PharmacyOfferReadRequest, pharmacy: Record<string, unknown>, scope: Awaited<ReturnType<typeof resolveOperationalScopeForActor>>, at: number): boolean {
  const e = offer.eligibility;
  if (offer.lifecycleStatus !== "ACTIVE" || at < Date.parse(e.startAt) || at > Date.parse(e.endAt)) return false;
  if (e.companyId !== text(pharmacy.companyId || pharmacy.company) || e.countryId !== text(pharmacy.countryId) || e.marketId !== text(pharmacy.marketId || pharmacy.countryId)) return false;
  if (e.pharmacyIds?.length && !e.pharmacyIds.includes(request.pharmacyId)) return false;
  if (e.pharmacyTypes?.length && !e.pharmacyTypes.includes(text(pharmacy.type || pharmacy.pharmacyType))) return false;
  if (e.geographyPaths?.length && !e.geographyPaths.some(path => path.countryId === text(pharmacy.countryId) && path.areaId === text(pharmacy.areaId) && (!text(pharmacy.districtId) || path.districtId === text(pharmacy.districtId)) && (!text(pharmacy.cityId) || path.cityId === text(pharmacy.cityId)))) return false;
  const authorizedProducts = new Set(scope.productIds), requested = request.productIds.filter(id => authorizedProducts.has(id));
  if (requested.length !== request.productIds.length || requested.length === 0) return false;
  const selectedProductIds: readonly string[] = offer.productScope.productIds;
  const trigger = offer.productScope.mode === "ALL_PRODUCTS" ? requested : requested.filter(id => selectedProductIds.includes(id));
  if (!trigger.length) return false;
  return !("reward" in offer.benefit && offer.benefit.reward.mode === "SELECTED_PRODUCT" && !authorizedProducts.has(offer.benefit.reward.rewardProductId));
}

export async function resolveScopedPharmacyOffers(actorUid: string, request: PharmacyOfferReadRequest, dependencies: { operationalScopeRepository?: OperationalScopeRepository; repository?: PharmacyOfferReadRepository; now?: () => Date } = {}) {
  const repository = dependencies.repository || createFirestorePharmacyOfferReadRepository();
  const user = await repository.getUser(actorUid), role = validateOfferActorProfile(actorUid, user), permissions = await repository.getPermissions(role);
  if (!hasOfferCapability(role, permissions, "offers.applyDuringVisit")) return { authorized: false, code: "OFFER_PERMISSION_DENIED" as const, offers: [] };
  const scope = await resolveOperationalScopeForActor(actorUid, {}, dependencies.operationalScopeRepository || createFirestoreOperationalScopeRepository());
  if (!scope.authorized || scope.queryPlan.denyAll) return { authorized: false, code: "OFFER_SCOPE_DENIED" as const, offers: [] };
  const pharmacy = await repository.getPharmacy(request.pharmacyId);
  if (!pharmacy) return { authorized: false, code: "OFFER_PHARMACY_NOT_FOUND" as const, offers: [] };
  if (!active(pharmacy)) return { authorized: false, code: "OFFER_PHARMACY_INACTIVE" as const, offers: [] };
  const actorCompanies = strings(user?.companyIds || user?.assignedCompanies || [user?.companyId || user?.company]);
  const pharmacyCompany = text(pharmacy.companyId || pharmacy.company);
  const actorMarkets = strings(user?.marketIds || user?.assignedMarkets);
  const pharmacyMarket = text(pharmacy.marketId || pharmacy.countryId);
  if (!pharmacyCompany || actorCompanies.length === 0 || !actorCompanies.includes(pharmacyCompany) || (actorMarkets.length > 0 && !actorMarkets.includes(pharmacyMarket))) return { authorized: false, code: "OFFER_SCOPE_DENIED" as const, offers: [] };
  if (!scope.areaIds.includes(text(pharmacy.areaId)) || !scope.countryIds.includes(text(pharmacy.countryId))) return { authorized: false, code: "OFFER_SCOPE_DENIED" as const, offers: [] };
  const productRecords = new Map<string, Record<string, unknown>>();
  for (const id of request.productIds) { const product = await repository.getProduct(id); if (!product) return { authorized: false, code: "OFFER_PRODUCT_NOT_FOUND" as const, offers: [] }; if (!commercial(product)) return { authorized: false, code: "OFFER_PRODUCT_INACTIVE" as const, offers: [] }; productRecords.set(id, product); }
  const offers: CanonicalOfferDefinition[] = [], candidates: CanonicalOfferDefinition[] = [];
  const authoritativeNow = (dependencies.now || (() => new Date()))().getTime();
  for (const document of await repository.queryActive()) {
    const parsed = validateCanonicalOfferDefinition({ ...document.data, id: document.id });
    if (!parsed.valid || !matchesOffer(parsed.value, request, pharmacy, scope, authoritativeNow)) continue;
    candidates.push(parsed.value);
  }
  for (const candidate of candidates) if ("reward" in candidate.benefit && candidate.benefit.reward.mode === "SELECTED_PRODUCT" && !productRecords.has(candidate.benefit.reward.rewardProductId)) { const product = await repository.getProduct(candidate.benefit.reward.rewardProductId); if (product) productRecords.set(candidate.benefit.reward.rewardProductId, product); }
  const unavailableOfferIds: string[] = [];
  for (const candidate of candidates) {
    if (!request.paidLines || (candidate.type !== "BUY_X_GET_Y" && candidate.type !== "TIER_BONUS")) { offers.push(candidate); continue; }
    const preview = calculateOffersForServer({ currencyCode: "XXX", decimalPlaces: 0, roundingMode: "DECIMAL_HALF_UP", paidLines: request.paidLines.map(line => ({ ...line, unitPrice: 0 })), selectedOffers: [candidate] });
    if (!preview.success || !physicalDemandIsAvailable(request.paidLines, preview.freeLines, productRecords)) unavailableOfferIds.push(candidate.id); else offers.push(candidate);
  }
  let selectedCombinationAvailable = true;
  if (request.paidLines && request.selectedOfferIds?.length) {
    const selected = request.selectedOfferIds.map(id => candidates.find(offer => offer.id === id));
    if (selected.some(offer => !offer)) selectedCombinationAvailable = false;
    else {
      const preview = calculateOffersForServer({ currencyCode: "XXX", decimalPlaces: 0, roundingMode: "DECIMAL_HALF_UP", paidLines: request.paidLines.map(line => ({ ...line, unitPrice: 0 })), selectedOffers: selected as CanonicalOfferDefinition[] });
      selectedCombinationAvailable = preview.success && preview.rejectedOffers.length === 0 && preview.conflicts.length === 0 && physicalDemandIsAvailable(request.paidLines, preview.freeLines, productRecords);
    }
  }
  return { authorized: true, capabilities: { "offers.applyDuringVisit": true }, offers: offers.sort((a, b) => a.id.localeCompare(b.id)), unavailableOfferIds: unavailableOfferIds.sort(), selectedCombinationAvailable };
}
